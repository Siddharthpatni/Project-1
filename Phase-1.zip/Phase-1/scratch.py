import os
from playwright.sync_api import sync_playwright

def scrape(url: str, output_dir: str):
    downloaded = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        page = context.new_page()
        
        page.goto(url)
        page.wait_for_load_state("networkidle")
        
        # 1. Accept cookies
        try:
            page.click('text="Alles akzeptieren"', timeout=5000)
            page.wait_for_load_state("networkidle")
        except:
            pass
        
        # 2. Click "Vergabeunterlagen ansehen" (No navigation expectation since it's a popup/modal)
        try:
            page.click('text="Vergabeunterlagen ansehen"', timeout=5000)
            page.wait_for_load_state("networkidle")
            page.wait_for_timeout(2000) # Wait for animation
            page.screenshot(path=os.path.join(output_dir, 'screenshot.png'))
        except Exception as e:
            print("Failed to click 'Vergabeunterlagen ansehen':", e)
            
        # 3. Print buttons to see what appeared in the popup
        buttons = page.eval_on_selector_all('button, a.btn, a', 'elements => elements.map(e => e.innerText.trim()).filter(t => t.length > 0)')
        print(f"BUTTONS AFTER CLICK: {buttons}")
        
        # 4. Try to click "Ohne Registrierung fortfahren" or "Als Gast"
        for text in ['Ohne Registrierung fortfahren', 'Als Gast weiter', 'Gastzugang', 'Kostenfrei weiter', 'Herunterladen', 'Alle Dokumente']:
            try:
                page.click(f'text="{text}"', timeout=3000)
                page.wait_for_load_state("networkidle")
                print(f"Clicked '{text}'!")
                page.wait_for_timeout(2000)
            except:
                pass
                
        # 5. Look for any download buttons in the final state
        try:
            with page.expect_download(timeout=15000) as download_info:
                # Try clicking any obvious download link
                page.locator("text='Alle herunterladen'").first.click()
            download = download_info.value
            path = os.path.join(output_dir, download.suggested_filename)
            download.save_as(path)
            downloaded.append(path)
            print(f"SUCCESS: Downloaded {download.suggested_filename}")
        except Exception as e:
            print("Failed to trigger 'Alle herunterladen':", e)

        browser.close()
        return {"downloaded_files": downloaded}
