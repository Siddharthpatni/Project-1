import asyncio, csv, json, time
from urllib.parse import urlparse
from playwright.async_api import async_playwright

# ---------- CONFIG ----------
INPUT_FILE = r"C:\Users\Victus\Downloads\publications_a.csv"
JSON_FILE = "data.json"
CSV_FILE = "data.csv"

WORKERS = 20              
NAV_TIMEOUT = 12000
RETRIES = 2

# ---------- XPATHS ----------
XP_TITLE = ["//h1", "//title"]

XP_AUTH = [
    "//*[contains(text(),'Auftraggeber')]/following-sibling::*[1]",
    "//*[contains(text(),'Vergabestelle')]/following-sibling::*[1]",
]

XP_DESC = [
    "//*[contains(text(),'Beschreibung')]/following-sibling::*[1]",
    "//article", "//main"
]

XP_DEADLINE = ["//*[contains(text(),'Frist')]/following-sibling::*[1]"]
XP_LOCATION = ["//*[contains(text(),'Ort')]/following-sibling::*[1]"]
XP_REF = ["//*[contains(text(),'Vergabenummer')]/following-sibling::*[1]"]


# ---------- CLEAN ----------
def clean(txt):
    if not txt:
        return None
    txt = txt.replace("\n", " ").replace("\r", " ").strip()
    if txt == ":" or len(txt) < 3:
        return None
    return txt[:800]


# ---------- MULTI XPATH ----------
async def grab(page, xps):
    for xp in xps:
        try:
            el = page.locator(f"xpath={xp}").first
            txt = await el.inner_text(timeout=1500)
            txt = clean(txt)
            if txt:
                return txt
        except:
            continue
    return None


# ---------- SAFE NAVIGATION ----------
async def safe_goto(page, url):
    for _ in range(RETRIES + 1):
        try:
            await page.goto(url, timeout=NAV_TIMEOUT, wait_until="domcontentloaded")
            return True
        except:
            await asyncio.sleep(0.5)
    return False


# ---------- SCRAPER ----------
async def scrape(page, url):
    start = time.time()

    try:
        if "login" in url:
            raise Exception("Login page")

        ok = await safe_goto(page, url)
        if not ok:
            raise Exception("Page load failed")

        html = await page.content()

        # 🚨 BLOCK DETECTION
        if any(x in html.lower() for x in ["captcha", "access denied", "forbidden"]):
            raise Exception("Blocked / Captcha")

        # ---------- EXTRACT ----------
        title = await grab(page, XP_TITLE)
        authority = await grab(page, XP_AUTH)
        description = await grab(page, XP_DESC)
        deadline = await grab(page, XP_DEADLINE)
        location = await grab(page, XP_LOCATION)
        reference = await grab(page, XP_REF)

        # ---------- STRICT VALIDATION ----------
        valid_fields = [title, authority, description]
        filled = sum(1 for x in valid_fields if x)

        if filled < 2:
            raise Exception("Insufficient data")

        if description and len(description) < 20:
            raise Exception("Weak description")

        scrape_time = round((time.time() - start) * 1000)

        return {
            "url": url,
            "domain": urlparse(url).netloc,
            "title": title,
            "authority": authority,
            "description": description,
            "summary": (description[:120] if description else title),
            "deadline": deadline,
            "location": location,
            "reference_number": reference,
            "scrape_time_ms": scrape_time,
            "status": "success",
            "error": None
        }

    except Exception as e:
        scrape_time = round((time.time() - start) * 1000)

        return {
            "url": url,
            "domain": urlparse(url).netloc,
            "title": None,
            "authority": None,
            "description": None,
            "summary": None,
            "deadline": None,
            "location": None,
            "reference_number": None,
            "scrape_time_ms": scrape_time,
            "status": "error",
            "error": str(e)[:150]
        }


# ---------- WORKER ----------
async def worker(context, queue, results, progress, total):
    page = await context.new_page()

    while True:
        try:
            idx, url = await queue.get()
        except:
            break

        res = await scrape(page, url)

        progress["count"] += 1
        current = progress["count"]
        percent = round((current / total) * 100, 2)

        results.append(res)

        print(f"[{current}/{total} | {percent}%] {res['domain']} | {res['status']} | {res['scrape_time_ms']}ms")

        queue.task_done()

    await page.close()


# ---------- MAIN ----------
async def main():


    START_FROM = 3500   # 🔥 change this anytime
    END_AT = None       # optional (e.g., 5000)

    urls = []

    with open(INPUT_FILE, encoding="latin-1") as f:
        all_rows = list(csv.DictReader(f))

    if END_AT:
        selected_rows = all_rows[START_FROM:END_AT]
    else:
        selected_rows = all_rows[START_FROM:]

    for row in selected_rows:
        if row.get("url"):
            urls.append(row["url"])

    total = len(urls)
    print(f"Total URLs: {total}")

    queue = asyncio.Queue()
    for i, url in enumerate(urls, 1):
        queue.put_nowait((i, url))

    results = []
    progress = {"count": 0}
    start_total = time.time()

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)

        context = await browser.new_context()

        workers = [
            asyncio.create_task(worker(context, queue, results, progress, total))
            for _ in range(WORKERS)
        ]

        await queue.join()

        for w in workers:
            w.cancel()

        await browser.close()

    total_time = round(time.time() - start_total, 2)

    print(f"\nTime: {total_time}s")
    print(f"Processed: {len(results)}")

    # ---------- DOMAIN STATS ----------
    domain_stats = {}
    for r in results:
        d = r["domain"]
        if d not in domain_stats:
            domain_stats[d] = {"total": 0, "success": 0}
        domain_stats[d]["total"] += 1
        if r["status"] == "success":
            domain_stats[d]["success"] += 1

    print("\n--- Per Domain Success ---")
    for d, stats in sorted(domain_stats.items(), key=lambda x: -x[1]["total"]):
        total_d = stats["total"]
        success = stats["success"]
        percent = round((success / total_d) * 100, 2) if total_d else 0
        print(f"{d:35} {success}/{total_d} ({percent}%)")

    # ---------- SUMMARY ----------
    summary = {
        "total_urls": total,
        "processed": len(results),
        "success": sum(1 for r in results if r["status"] == "success"),
        "errors": sum(1 for r in results if r["status"] == "error"),
        "total_time_sec": total_time,
    }

    # ---------- SAVE JSON ----------
    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "data": results}, f, indent=2, ensure_ascii=False)

    # ---------- SAFE CSV WRITE ----------
    columns = [
        "url", "domain", "status", "title", "authority",
        "summary", "deadline", "location",
        "reference_number", "scrape_time_ms", "error"
    ]

    while True:
        try:
            with open(CSV_FILE, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=columns)
                writer.writeheader()
                for r in results:
                    writer.writerow({c: r.get(c, "N/A") for c in columns})
            break
        except PermissionError:
            print(" Close data.csv and press ENTER...")
            input()

    print("\nSaved: data.json & data.csv")


# ---------- RUN ----------
if __name__ == "__main__":
    asyncio.run(main())
