import asyncio
import json
import os
import time
import logging
import random
import re
import pandas as pd
import httpx
from dataclasses import dataclass, field
from urllib.parse import urlparse
from typing import List, Dict
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from datetime import datetime

# ---------- LOGGING ----------
logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger("XPathTenderScraper")

# ---------- CONFIG ----------
CONFIG = {
    "INPUT_FILE": r"C:\Users\Victus\Downloads\Project-1-main\Project-1-main\publications_a.csv",
    "URL_LIMIT": 100,
    "CSV_OUT": "LLM.csv",
    "JSON_OUT": "LLM.json",
    "STATS_OUT": "website_performance.csv",  #  NEW STATS FILE
    "ROOT_DIR": "tender_pdfs",
    "CONCURRENCY": 3,
    "TIMEOUT_MS": 45000,
    "OPENAI_API_KEY": "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",
    "USE_LLM_FALLBACK": True,
    "GPT4O_MINI_PRICE_PER_MILLION_TOKENS": 0.15 / 1000,  # $0.15 per 1M input tokens
    "USER_AGENTS": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    ]
}

@dataclass
class TenderResult:
    title: str = ""
    authority: str = ""
    description: str = ""
    deadline: str = ""
    location: str = ""
    reference_id: str = ""
    url: str = ""
    domain: str = ""
    status: str = "FAILED"
    scraped_time: str = ""
    extraction_method: str = "NONE"

@dataclass
class PerformanceStats:
    url: str = ""
    domain: str = ""
    status: str = ""
    extraction_method: str = ""
    load_time_ms: float = 0.0
    content_length: int = 0
    tokens_used: int = 0
    cost_usd: float = 0.0
    success: bool = False

# ---------- XPATH EXTRACTION ----------
async def xpath_extract(page, content: str) -> TenderResult:
    result = TenderResult()
    
    xpath_selectors = {
        "title": ["//h1[contains(text(),'tender') or contains(text(),'contract')]/text()", "//h1/text()", "//title/text()"],
        "authority": ["//*[contains(text(),'authority') or contains(text(),'buyer')]/following::text()[1]"],
        "reference_id": ["//*[contains(text(),'ref') or contains(text(),'Ref')]/following::text()[1]"],
        "deadline": ["//*[contains(text(),'deadline') or contains(text(),'Deadline')]/following::text()[1]"],
        "location": ["//*[contains(text(),'location') or contains(text(),'Location')]/following::text()[1]"]
    }
    
    try:
        for field, xpaths in xpath_selectors.items():
            for xpath in xpaths:
                try:
                    elements = page.locator(f"xpath={xpath}").all()
                    for el in elements[:2]:
                        text = await el.inner_text()
                        if text and len(text.strip()) > 3:
                            clean_text = re.sub(r'[\n\t\r]+', ' ', text.strip())
                            setattr(result, field, clean_text[:150 if field == 'title' else 100])
                            break
                    if getattr(result, field):
                        break
                except:
                    continue
        
        if not result.title:
            result = regex_extract(content)
        
        result.description = re.sub(r'[\n\r\t]+', ' ', content[:500]).strip()
        result.extraction_method = "XPATH" if result.title or result.reference_id else "REGEX"
        
        if result.title or result.reference_id or result.deadline:
            result.status = "SUCCESS"
        
    except:
        result = regex_extract(content)
    
    return result

# ---------- REGEX FALLBACK ----------
def regex_extract(text: str) -> TenderResult:
    result = TenderResult()
    patterns = {
        "title": [r'(?:tender|contract|notice|procurement|subject|title)[:\-]?\s*(.+?)(?=\n\n|\n\d|deadline)'],
        "authority": [r'(?:authority|buyer|client)[:\-]?\s*(.+?)(?=\n|$)'],
        "reference_id": [r'ref(?:erence)?[:\-]?\s*([A-Z0-9\-/]+)', r'(?:no?|id)[:\-]?\s*([A-Z0-9\-/]+)'],
        "deadline": [r'deadline[:\s]*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{4})', r'(\d{1,2}[./\-]\d{1,2}[./\-]\d{4})'],
        "location": [r'location[:\-]?\s*(.+?)(?=\n|$)']
    }
    
    for field, pats in patterns.items():
        for pat in pats:
            match = re.search(pat, text, re.IGNORECASE | re.DOTALL)
            if match:
                value = match.group(1).strip()
                if len(value) > 3:
                    setattr(result, field, value[:150 if field == 'title' else 100])
                    break
    
    result.description = re.sub(r'[\n\r\t]+', ' ', text[:500]).strip()
    result.extraction_method = "REGEX"
    
    if result.title or result.reference_id or result.deadline:
        result.status = "SUCCESS"
    
    return result

# ---------- LLM FALLBACK WITH TOKEN TRACKING ----------
async def llm_fallback(text: str, url: str, stats: PerformanceStats) -> TenderResult:
    prompt = f"Extract tender data. JSON only: {{ \"title\": \"max 100\", \"authority\": \"\", \"deadline\": \"DD/MM/YYYY\", \"location\": \"\", \"reference_id\": \"\", \"description\": \"max 300\" }} URL: {url} Content: {text[:4000]}"
    
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {CONFIG['OPENAI_API_KEY']}", "Content-Type": "application/json"},
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_tokens": 500
                }
            )
            
            data = response.json()
            usage = data.get("usage", {})
            tokens_used = usage.get("total_tokens", 0)
            cost = tokens_used * CONFIG["GPT4O_MINI_PRICE_PER_MILLION_TOKENS"]
            
            stats.tokens_used = tokens_used
            stats.cost_usd = round(cost, 6)
            
            content = data["choices"][0]["message"]["content"]
            start = content.find('{')
            end = content.rfind('}') + 1
            parsed = json.loads(content[start:end])
            
            result = TenderResult()
            for key in ["title", "authority", "deadline", "location", "reference_id", "description"]:
                if key in parsed:
                    setattr(result, key, str(parsed[key])[:150 if key=="title" else 100])
            
            result.extraction_method = "LLM"
            result.status = "SUCCESS_LLM"
            logger.info(f" LLM SUCCESS | Tokens: {tokens_used} | Cost: ${cost:.6f}")
            return result
            
    except Exception as e:
        logger.warning(f"LLM failed: {e}")
        stats.status = "LLM_FAILED"
        return TenderResult(status="LLM_FAILED")

# ---------- MAIN SCRAPER ----------
async def scrape_single_url(context, url: str) -> tuple[TenderResult, PerformanceStats]:
    domain = urlparse(url).netloc
    result = TenderResult(url=url, domain=domain)
    stats = PerformanceStats(url=url, domain=domain)
    stats.scraped_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    load_start = time.time()
    page = await context.new_page()
    
    try:
        await page.set_extra_http_headers({"User-Agent": random.choice(CONFIG["USER_AGENTS"])})
        await page.goto(url, timeout=CONFIG["TIMEOUT_MS"], wait_until="domcontentloaded")
        stats.load_time_ms = (time.time() - load_start) * 1000
        await page.wait_for_timeout(4000)
        
        content = await page.evaluate("""
            () => {
                let text = '';
                const selectors = ['body', 'main', '.content', '.main-content', '.article', '[role="main"]'];
                for (let sel of selectors) {
                    const els = document.querySelectorAll(sel);
                    for (let el of els) {
                        if (el?.innerText?.length > 50) text += el.innerText + '\\n\\n';
                    }
                }
                return text.substring(0, 15000);
            }
        """)
        
        stats.content_length = len(content)
        
        if len(content) < 100:
            stats.status = "LOW_CONTENT"
            return result, stats
        
        # STEP 1: XPATH
        result = await xpath_extract(page, content)
        if result.status == "SUCCESS":
            stats.status = "SUCCESS"
            stats.extraction_method = result.extraction_method
            stats.success = True
            logger.info(f" XPATH {domain}")
            return result, stats
        
        # STEP 2: REGEX
        regex_result = regex_extract(content)
        if regex_result.status == "SUCCESS":
            result.__dict__.update(regex_result.__dict__)
            stats.status = "SUCCESS"
            stats.extraction_method = "REGEX"
            stats.success = True
            logger.info(f" REGEX {domain}")
            return result, stats
        
        # STEP 3: LLM with token tracking
        if CONFIG["USE_LLM_FALLBACK"]:
            logger.info(f" LLM for {domain}")
            llm_result = await llm_fallback(content, url, stats)
            result.__dict__.update(llm_result.__dict__)
            stats.success = (result.status == "SUCCESS_LLM")
            return result, stats
        
        stats.status = "ALL_FAILED"
        return result, stats
        
    except Exception as e:
        stats.status = f"ERROR: {str(e)[:30]}"
        logger.error(f" ERROR {domain}: {e}")
    
    finally:
        await page.close()
    
    return result, stats

# ---------- MAIN ----------
async def main():
    if not os.path.exists(CONFIG["INPUT_FILE"]):
        print(f" File not found: {CONFIG['INPUT_FILE']}")
        return
    
    df = pd.read_csv(CONFIG["INPUT_FILE"])
    urls = df["url"].dropna().str.strip().unique().tolist()
    urls = [u for u in urls if u.startswith(('http://', 'https://'))][:CONFIG["URL_LIMIT"]]
    
    print(f" XPATH Scraper with Performance Tracking | {len(urls)} URLs")
    
    results = []
    perf_stats = []
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(viewport={'width': 1366, 'height': 768})
        
        sem = asyncio.Semaphore(CONFIG["CONCURRENCY"])
        
        async def process_url(url):
            async with sem:
                result, stats = await scrape_single_url(context, url)
                results.append(result.__dict__)
                perf_stats.append(stats.__dict__)
                await asyncio.sleep(random.uniform(1.5, 3.0))
        
        await asyncio.gather(*[process_url(url) for url in urls])
        await browser.close()
    
    # ---------- SAVE FILES ----------
    # Main data
    df_final = pd.DataFrame(results)
    columns = ["title", "authority", "description", "deadline", "location", 
               "reference_id", "url", "domain", "status", "scraped_time", "extraction_method"]
    df_final = df_final.reindex(columns=columns, fill_value="")
    df_final.to_csv(CONFIG["CSV_OUT"], index=False, encoding='utf-8')
    
    # PERFORMANCE STATS 
    df_perf = pd.DataFrame(perf_stats)
    perf_columns = ["url", "domain", "status", "extraction_method", "load_time_ms", 
                   "content_length", "tokens_used", "cost_usd", "success", "scraped_time"]
    df_perf = df_perf.reindex(columns=perf_columns, fill_value=0)
    df_perf.to_csv(CONFIG["STATS_OUT"], index=False, encoding='utf-8')
    
    # JSON
    with open(CONFIG["JSON_OUT"], "w", encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f" Saved {len(results)} rows → {CONFIG['CSV_OUT']}")
    print(f" Performance → {CONFIG['STATS_OUT']}")
    print(f" Saved JSON → {CONFIG['JSON_OUT']}")
    
    #  FINAL STATS
    total_success = len([s for s in perf_stats if s.success])
    total_cost = sum(s.cost_usd for s in perf_stats)
    total_tokens = sum(s.tokens_used for s in perf_stats)
    
    print(f"\n PERFORMANCE SUMMARY:")
    print(f"   Success Rate: {total_success}/{len(perf_stats)} ({total_success/len(perf_stats)*100:.1f}%)")
    print(f"   Total Cost: ${total_cost:.6f}")
    print(f"   Total Tokens: {total_tokens:,}")
    print(f"   XPATH: {len([s for s in perf_stats if s.extraction_method == 'XPATH'])}")
    print(f"   REGEX: {len([s for s in perf_stats if s.extraction_method == 'REGEX'])}")
    print(f"   LLM: {len([s for s in perf_stats if s.extraction_method == 'LLM'])}")

if __name__ == "__main__":
    asyncio.run(main())
