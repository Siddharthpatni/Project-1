﻿### 1. Executive Side-by-Side Summary

| Metric | Phase 1 Scraper | CUA Agent | % Difference / Delta |
| :--- | :--- | :--- | :--- |
| **Success Rate (%)** | 10.0% (2/20) | 15.0% (3/20) | +5.0 pp |
| **Total URLs Tested** | 20 | 20 | 0% |
| **Avg. Runtime / Task (all runs)** | 10.1 s | 154.5 s | +1430% |
| **Avg. Runtime / Successful Task** | 7.6 s | 161.4 s | +2024% |
| **Avg. Steps / Task** | 3.5 | 12.4 | +254% |
| **Total Screenshots Taken** | 0 | 229 | n/a |
| **Total Accumulated Cost** | $0.0000 | $2.2376 | n/a (P1 = $0) |
| **Cost per Success** | $0.0000 | $0.7459 | n/a (P1 = $0) |
| **Total Documents Downloaded** | 8 | 19 | +138% |


### 2. Per-URL Granular Breakdown

| # | Domain | Annot. | P1 Outcome | P1 Steps | P1 Time (s) | P1 Cost | CUA Outcome | CUA Steps | CUA Shots | CUA Time (s) | CUA Cost |
| :- | :--- | :-- | :-- | :-: | :-: | :-: | :-- | :-: | :-: | :-: | :-: |
| 1 | www.evergabe.de | COMP | FAIL (0 f) | 3 | 18.294 | $0.00 | FAIL (0 f) | 24 | 23 | 286.898 | $0.2262 |
| 2 | www.evergabe.de | FAIL | FAIL (0 f) | 3 | 16.284 | $0.00 | FAIL (0 f) | 24 | 23 | 260.263 | $0.2636 |
| 3 | www.subreport.de | COMP | PASS (4 f) | 5 | 7.407 | $0.00 | FAIL (0 f) | 6 | 5 | 72.449 | $0.0464 |
| 4 | www.subreport.de | FAIL | PASS (4 f) | 5 | 7.72 | $0.00 | PASS (1 f) | 11 | 10 | 98.573 | $0.1084 |
| 5 | vergabemarktplatz.brandenburg.de | COMP | FAIL (0 f) | 2 | 7.145 | $0.00 | FAIL (0 f) | 12 | 12 | 392.394 | $0.0757 |
| 6 | vergabe.niedersachsen.de | COMP | FAIL (0 f) | 2 | 7.144 | $0.00 | FAIL (0 f) | 15 | 14 | 160.772 | $0.1273 |
| 7 | bieterzugang.deutsche-evergabe.de | FAIL | FAIL (0 f) | 1 | 5.987 | $0.00 | FAIL (0 f) | 2 | 1 | 32.111 | $0.0101 |
| 8 | www.evergabe.nrw.de | COMP | FAIL (0 f) | 2 | 7.104 | $0.00 | PASS (2 f) | 21 | 20 | 190.244 | $0.1854 |
| 9 | www.vergabe-westfalen.de | COMP | FAIL (0 f) | 2 | 7.116 | $0.00 | FAIL (0 f) | 21 | 20 | 221.79 | $0.1921 |
| 10 | www.deutsches-ausschreibungsblatt.de | FAIL | FAIL (0 f) | 8 | 12.777 | $0.00 | FAIL (0 f) | 17 | 16 | 206.668 | $0.1497 |
| 11 | www.had.de | COMP | FAIL (0 f) | 2 | 16.883 | $0.00 | FAIL (0 f) | 20 | 19 | 205.492 | $0.1729 |
| 12 | www.vergabe.metropoleruhr.de | COMP | FAIL (0 f) | 2 | 7.094 | $0.00 | FAIL (0 f) | 21 | 20 | 214.694 | $0.1979 |
| 13 | fbhh-evergabe.web.hamburg.de | FAIL | FAIL (0 f) | 1 | 6.278 | $0.00 | FAIL (0 f) | 2 | 1 | 50.68 | $0.0100 |
| 14 | bi-medien.de | COMP | FAIL (0 f) | 3 | 16.745 | $0.00 | FAIL (0 f) | 6 | 5 | 82.485 | $0.0467 |
| 15 | www.tender24.de | FAIL | FAIL (0 f) | 8 | 11.846 | $0.00 | FAIL (0 f) | 7 | 6 | 95.403 | $0.0570 |
| 16 | vergabe.landbw.de | COMP | FAIL (0 f) | 8 | 12.255 | $0.00 | FAIL (0 f) | 2 | 1 | 38.754 | $0.0104 |
| 17 | vergabekooperation.berlin | FAIL | FAIL (0 f) | 8 | 12.663 | $0.00 | FAIL (0 f) | 2 | 1 | 32.344 | $0.0101 |
| 18 | www.evergabe.bayern.de | COMP | FAIL (0 f) | 1 | 5.92 | $0.00 | FAIL (0 f) | 2 | 1 | 44.697 | $0.0097 |
| 19 | vergabeportal-bw.de | FAIL | FAIL (0 f) | 2 | 7.027 | $0.00 | FAIL (0 f) | 23 | 22 | 207.168 | $0.2162 |
| 20 | s2c.mercell.com | UNSU | FAIL (0 f) | 1 | 7.519 | $0.00 | PASS (16 f) | 10 | 9 | 195.521 | $0.1217 |
