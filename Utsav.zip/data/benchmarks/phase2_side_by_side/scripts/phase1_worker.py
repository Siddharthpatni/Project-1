"""
Phase 1 scraper worker — standalone, instrumented port of the project's
scripted (non-LLM) scraping cascade:

  Stage 0  DETERMINISTIC  — platform classification by URL pattern; for the
           DTVP/Satellite/VMPSatellite and NetServer families the document
           ZIP URL is constructed directly and fetched over plain HTTP
           (port of backend/app/phase3_integration/deterministic.py +
            platform_classifier.py).
  Stage 1  HEURISTIC      — hand-crafted Playwright scraper with generic
           download heuristics (port of
            backend/app/phase0_manual/v1_reference.py).

No LLM calls anywhere -> $0.00 task cost. Step counters (navigations /
clicks / HTTP requests) added for benchmark instrumentation; scraping
logic itself is unchanged from the source modules.

Usage:  python phase1_worker.py <url> <output_dir>
Emits:  '@@RESULT@@{json}' on stdout as the last line.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sys
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
from playwright.sync_api import sync_playwright

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="%(asctime)s [P1] %(message)s")
log = logging.getLogger("phase1")

# ── Benchmark instrumentation ──────────────────────────────────────────────
METRICS = {"navigations": 0, "clicks": 0, "http_requests": 0}

# ── Configuration (identical to v1_reference) ──────────────────────────────
DOCUMENT_EXTENSIONS = frozenset({
    ".pdf", ".zip", ".doc", ".docx", ".xls", ".xlsx", ".rar", ".7z",
    ".odt", ".ods", ".p7s", ".gaeb", ".x81", ".x83", ".d83", ".d84",
    ".ppt", ".pptx", ".txt", ".csv",
})

DOC_TEXT_KEYWORDS = [
    "unterlag", "leistungsverzeichnis", "leistungsbeschreibung",
    "ausschreibung", "vergabeunterlag", "angebotsunterlag",
    "gaeb", "download", "dokument", "alle dokumente",
    "bekanntmachung", "eigenerklärung", "fragen", "antworten",
    "unterlagen", "datei", "herunterladen", "attachment",
]

DOWNLOAD_ALL_TEXTS = [
    "alle herunterladen", "alle dokumente", "alle unterlagen", "alle als zip",
    "alles herunterladen", "download all", "download zip", "zip herunterladen",
    "unterlagen herunterladen", "alle vergabeunterlagen", "gesamtpaket",
    "vergabeunterlagen herunterladen", "unterlagen als zip", "als zip",
    "alle dateien", "complete documents", "télécharger tout",
]

DOC_SKIP_TEXT = ["agb", "datenschutz", "impressum", "login", "registrierung", "cookie"]

NETSERVER_URL_TEMPLATES = [
    "https://www.vergabe24.de/NetServer/TenderingProcedureDetails?function=_Details&TenderOID={tid}",
    "https://www.tender24.de/NetServer/TenderingProcedureDetails?function=_Details&TenderOID={tid}",
]

BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "de-DE,de;q=0.9,en;q=0.7",
}

_MAX_DOWNLOAD_BYTES = 200 * 1024 * 1024  # 200 MB


# ── URL Recovery (NetServer) ───────────────────────────────────────────────
def extract_tender_id(url: str) -> str | None:
    m = re.search(r"(54321-(?:Tender|PublishingProcess)-[a-f0-9][a-f0-9\-]+)", url, re.IGNORECASE)
    return m.group(1) if m else None


def recover_url(original_url: str) -> str:
    tid = extract_tender_id(original_url)
    if not tid:
        return original_url
    for template in NETSERVER_URL_TEMPLATES:
        candidate = template.format(tid=tid)
        try:
            METRICS["http_requests"] += 1
            r = requests.get(candidate, headers=BROWSER_HEADERS, timeout=5)
            if r.status_code == 200 and len(r.text) > 1000:
                return candidate
        except requests.RequestException:
            continue
    return original_url


# ── Helpers ────────────────────────────────────────────────────────────────
def dismiss_cookies(page) -> None:
    selectors = [
        "xpath=//button[contains(.,'Akzeptieren')]",
        "xpath=//button[contains(.,'Alle akzeptieren')]",
        "xpath=//button[contains(.,'Annehmen')]",
        "xpath=//button[contains(.,'Accept')]",
        "xpath=//button[contains(.,'Zustimmen')]",
        "text=Einverstanden",
        "#accept-cookies", ".cookie-accept", "[id*=accept]",
    ]
    for sel in selectors:
        try:
            if page.is_visible(sel, timeout=400):
                page.click(sel, timeout=400)
                METRICS["clicks"] += 1
                return
        except Exception:
            pass


def score_link(href: str, text: str | None, domain: str) -> int:
    low_href = href.lower()
    low_text = (text or "").lower().strip()

    if any(k in low_href for k in ["/agb", "/login", "/register", "/datenschutz", "/impress"]):
        return 0
    if any(k in low_text for k in DOC_SKIP_TEXT):
        return 0

    if any(p in low_href for p in ["downloadall", "alleherunterladen", "download-all",
                                     "zipdownloadbutton", "downloadallbutton", "archive",
                                     "alle-dokumente", "gesamtpaket"]):
        return 10

    if low_href.endswith(".zip") or ".zip?" in low_href:
        return 9

    score = 0
    ext = Path(urlparse(href).path).suffix.lower()
    if ext in DOCUMENT_EXTENSIONS:
        score += 3
    if any(k in low_text for k in DOC_TEXT_KEYWORDS):
        score += 2
    if any(e in low_text for e in [".pdf", ".zip", ".docx"]):
        score += 1

    return score


def _save_download(download, output_dir: str, fallback_name: str) -> str | None:
    name = download.suggested_filename or fallback_name
    save_path = os.path.join(output_dir, name)
    try:
        download.save_as(save_path)
        size = os.path.getsize(save_path)
        if size < 100:
            os.unlink(save_path)
            return None
        with open(save_path, "rb") as f:
            hdr = f.read(512).lower()
        if b"<html" in hdr or b"<!doctype" in hdr:
            os.unlink(save_path)
            return None
        log.info("saved %s (%d bytes)", name, size)
        return save_path
    except Exception as e:
        log.debug("save failed %s: %s", name, e)
        return None


def _download_http(url: str, output_dir: str, name: str) -> str | None:
    save_path = os.path.join(output_dir, name)
    for attempt in range(3):
        try:
            METRICS["http_requests"] += 1
            with requests.get(url, headers=BROWSER_HEADERS, timeout=25, stream=True) as r:
                if r.status_code >= 400:
                    return None
                ct = r.headers.get("content-type", "").lower()
                if "text/html" in ct:
                    return None
                cl = r.headers.get("content-length")
                if cl and int(cl) > _MAX_DOWNLOAD_BYTES:
                    return None

                written = 0
                with open(save_path, "wb") as f:
                    for chunk in r.iter_content(65536):
                        if chunk:
                            written += len(chunk)
                            if written > _MAX_DOWNLOAD_BYTES:
                                os.unlink(save_path)
                                return None
                            f.write(chunk)

                if written < 200:
                    os.unlink(save_path)
                    return None
                with open(save_path, "rb") as f:
                    hdr = f.read(512).lower()
                if b"<html" in hdr or b"<!doctype" in hdr:
                    os.unlink(save_path)
                    return None
                return save_path
        except requests.RequestException as e:
            log.debug("http error %s attempt %d: %s", url, attempt + 1, e)
            if attempt < 2:
                time.sleep(1)
    return None


# ── Stage 0: deterministic platform branch ────────────────────────────────
# Port of phase3_integration/platform_classifier.py (dtvp + netserver only)
# and phase3_integration/deterministic.py.

_DETERMINISTIC_URL_PATTERNS = {
    "dtvp": [
        r"/Satellite/public/company/project/",
        r"/VMPSatellite/public/company/project/",
        r"/Satellite/notice/",
        r"/VMPSatellite/notice/",
        r"/Vergabe/notice/",
        r"/Vergabe/public/company/project/",
    ],
    "netserver": [
        r"/NetServer/",
    ],
}


def classify_deterministic(url: str) -> str | None:
    for platform, patterns in _DETERMINISTIC_URL_PATTERNS.items():
        for p in patterns:
            if re.search(p, url, re.IGNORECASE):
                return platform
    return None


def _extract_project_id(url: str) -> str | None:
    m = re.search(r"/(?:project|notice)/([A-Z0-9a-z]+)(?:/|$)", url, re.IGNORECASE)
    return m.group(1) if m else None


def _dtvp_prefix(url: str) -> str:
    if "/VMPSatellite/" in url:
        return "VMPSatellite"
    if "/Vergabe/" in url:
        return "Vergabe"
    return "Satellite"


def build_dtvp_zip_url(url: str) -> str | None:
    parts = urlparse(url)
    project_id = _extract_project_id(url)
    if not project_id:
        return None
    prefix = _dtvp_prefix(url)
    return (f"{parts.scheme}://{parts.netloc}"
            f"/{prefix}/public/company/project/{project_id}"
            f"/de/documents/archive/Vergabeunterlagen_{project_id}.zip")


def _netserver_oid_and_base(url: str) -> tuple[str | None, str]:
    from urllib.parse import parse_qs
    parts = urlparse(url)
    params = parse_qs(parts.query, keep_blank_values=True)
    base = f"{parts.scheme}://{parts.netloc}"
    netpath = re.search(r"(/.*?/NetServer/)", parts.path, re.IGNORECASE)
    ns_base = f"{base}{netpath.group(1)}" if netpath else f"{base}/NetServer/"
    oid = (params.get("TenderOID") or params.get("TWOID") or [None])[0]
    if not oid:
        m = re.search(r"(54321-(?:Tender|PublishingProcess)-[a-f0-9\-]+)", url, re.IGNORECASE)
        oid = m.group(1) if m else None
    return oid, ns_base


def build_netserver_urls(url: str) -> list[str]:
    oid, ns_base = _netserver_oid_and_base(url)
    if not oid:
        return []
    return [
        f"{ns_base}TenderingProcedureDetails?function=_DownloadTenderDocuments&TenderOID={oid}",
        f"{ns_base}TenderingProcedureDetails?function=_DownloadPublicationDocuments&TenderOID={oid}",
        f"{ns_base}PublicationControllerServlet?function=GetDocumentFile&TWOID={oid}",
        f"{ns_base}TenderingProcedureDetails?function=_DownloadTenderDocuments&TenderOID={oid}&DocumentType=0",
        f"{ns_base}TenderingProcedureDetails?function=_DownloadTenderDocuments&TenderOID={oid}&DocumentType=1",
    ]


def try_deterministic(url: str, output_dir: str) -> list[str]:
    """DETERMINISTIC cascade branch: construct + fetch, no browser at all."""
    platform = classify_deterministic(url)
    if platform is None:
        return []
    if platform == "dtvp":
        zip_url = build_dtvp_zip_url(url)
        candidates = [zip_url] if zip_url else []
    else:
        candidates = build_netserver_urls(url)
    for i, cand in enumerate(candidates):
        log.info("deterministic[%s] try %s", platform, cand)
        name = os.path.basename(urlparse(cand).path) or f"det_{i}.bin"
        if "." not in name:
            name += ".zip" if platform == "dtvp" else ".bin"
        saved = _download_http(cand, output_dir, name)
        if saved:
            log.info("deterministic hit: %s", saved)
            return [saved]
    return []


# ── Stage 1: heuristic browser scraper (logic identical to v1_reference) ───
def scrape(url: str, output_dir: str) -> list[str]:
    downloaded: list[str] = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        try:
            context = browser.new_context(
                accept_downloads=True,
                user_agent=BROWSER_HEADERS["User-Agent"],
                extra_http_headers={"Accept-Language": "de-DE,de;q=0.9,en;q=0.7"},
            )
            page = context.new_page()

            final_url = recover_url(url)
            try:
                METRICS["navigations"] += 1
                page.goto(final_url, wait_until="domcontentloaded", timeout=30000)
                page.wait_for_timeout(2500)
                dismiss_cookies(page)
                page.wait_for_timeout(1500)
            except Exception as e:
                log.warning("goto failed %s: %s", final_url, e)
                return []

            for _ in range(8):
                try:
                    pluses = page.query_selector_all("img[src*='plus']")
                    if not pluses:
                        break
                    clicked = False
                    for el in pluses:
                        try:
                            if el.is_visible():
                                el.click(force=True)
                                METRICS["clicks"] += 1
                                clicked = True
                        except Exception:
                            pass
                    if not clicked:
                        break
                    page.wait_for_timeout(1200)
                except Exception:
                    break

            try:
                dl_all = _find_download_all(page)
                if dl_all:
                    log.info("download-all element found")
                    with page.expect_download(timeout=30000) as di:
                        dl_all.click(force=True)
                        METRICS["clicks"] += 1
                    saved = _save_download(di.value, output_dir, "all_documents.zip")
                    if saved:
                        downloaded.append(saved)
                        return downloaded
            except Exception as e:
                log.debug("download-all failed: %s", e)

            candidates: list[tuple[str, int, object]] = []
            seen_urls: set[str] = set()

            try:
                for link in page.query_selector_all("a[href]"):
                    try:
                        href = link.get_attribute("href") or ""
                        text = link.inner_text()
                        if not href or href.startswith("#") or href.startswith("javascript"):
                            continue
                        full = urljoin(page.url, href)
                        if full in seen_urls:
                            continue
                        s = score_link(full, text, urlparse(page.url).netloc)
                        if s > 0:
                            seen_urls.add(full)
                            candidates.append((full, s, link))
                    except Exception:
                        continue
            except Exception as e:
                log.debug("link query error: %s", e)

            try:
                for btn in page.query_selector_all("button, input[type=button], input[type=submit]"):
                    try:
                        text = (btn.inner_text() or btn.get_attribute("value") or "").lower()
                        if any(k in text for k in ["download", "herunterladen", "unterlag", "zip", "dokument"]):
                            candidates.append(("button:" + text[:40], 4, btn))
                    except Exception:
                        continue
            except Exception:
                pass

            candidates.sort(key=lambda x: -x[1])
            log.info("candidates: %d", len(candidates))

            content_hashes: set[str] = set()

            for i, (doc_url, score, element) in enumerate(candidates[:80]):
                if len(downloaded) >= 50:
                    break

                try:
                    with page.expect_download(timeout=8000) as di:
                        element.click(force=True)
                        METRICS["clicks"] += 1
                    saved = _save_download(di.value, output_dir, f"doc_{i}.bin")
                    if saved:
                        _add_if_new(saved, content_hashes, downloaded)
                    continue
                except Exception:
                    pass

                if str(doc_url).startswith("button:"):
                    continue

                try:
                    url_ext = Path(urlparse(doc_url).path).suffix.lower()
                    if url_ext not in DOCUMENT_EXTENSIONS and score < 3:
                        continue
                    ext = url_ext if url_ext in DOCUMENT_EXTENSIONS else ".bin"
                    name = f"doc_{i}_{hashlib.md5(doc_url.encode()).hexdigest()[:6]}{ext}"
                    saved = _download_http(doc_url, output_dir, name)
                    if saved:
                        _add_if_new(saved, content_hashes, downloaded)
                except Exception as e:
                    log.debug("http fallback error %s: %s", doc_url, e)

        except Exception as e:
            log.error("fatal %s: %s", url, e)
        finally:
            try:
                browser.close()
            except Exception:
                pass

    log.info("done %s files=%d", url, len(downloaded))
    return downloaded


def _find_download_all(page):
    for btn in page.query_selector_all("button, a, input[type=button]"):
        try:
            text = (btn.inner_text() or btn.get_attribute("value") or "").lower().strip()
            if any(t in text for t in DOWNLOAD_ALL_TEXTS) and btn.is_visible():
                return btn
        except Exception:
            continue

    for a in page.query_selector_all("a[href]"):
        try:
            href = (a.get_attribute("href") or "").lower()
            text = a.inner_text().lower()
            if not a.is_visible():
                continue
            if any(p in href for p in ["downloadall", "alleherunterladen", "download-all",
                                        "zipdownloadbutton", "downloadallbutton",
                                        "archive", "gesamtpaket"]):
                return a
            if any(t in text for t in DOWNLOAD_ALL_TEXTS):
                return a
        except Exception:
            continue

    return None


def _add_if_new(path: str, hashes: set, downloaded: list) -> None:
    try:
        with open(path, "rb") as f:
            h = hashlib.sha256(f.read(4096)).hexdigest()
        if h in hashes:
            try:
                os.unlink(path)
            except OSError:
                pass
        else:
            hashes.add(h)
            downloaded.append(path)
    except Exception:
        downloaded.append(path)


def main():
    url, output_dir = sys.argv[1], sys.argv[2]
    os.makedirs(output_dir, exist_ok=True)
    t0 = time.perf_counter()
    files: list[str] = []
    error = ""
    stage = "deterministic"
    try:
        files = try_deterministic(url, output_dir)
        if not files:
            stage = "heuristic_browser"
            files = scrape(url, output_dir)
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
    runtime = time.perf_counter() - t0

    result = {
        "framework": "phase1",
        "url": url,
        "domain": urlparse(url).netloc,
        "winning_stage": stage if files else None,
        "outcome": "success" if files else "failure",
        "files_downloaded": len(files),
        "files": [{"name": os.path.basename(p), "bytes": os.path.getsize(p)}
                  for p in files if os.path.exists(p)],
        "steps": {
            **METRICS,
            "total": METRICS["navigations"] + METRICS["clicks"] + METRICS["http_requests"],
        },
        "screenshots_taken": 0,
        "runtime_s": round(runtime, 3),
        "llm_tokens": {"prompt": 0, "completion": 0, "image": 0},
        "cost_usd": 0.0,
        "error": error,
    }
    print("@@RESULT@@" + json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
