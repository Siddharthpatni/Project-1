"""
Emit the data-driven markdown fragments for PHASE_2_BENCHMARK_REPORT.md:
  * executive side-by-side summary table
  * per-URL granular breakdown table
Printed to stdout so the numbers in the report come straight from the logs.
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).parent          # scripts/
BASE = HERE.parent                    # benchmark root
RESULT = BASE / "results"


def load(fw: str) -> list[dict]:
    return json.loads((RESULT / f"{fw}_results.json").read_text(encoding="utf-8"))


def fmt_delta(p1, cua, unit="", invert=False, pct=False):
    if p1 in (None, 0) or cua is None:
        return "n/a"
    if pct:
        return f"{cua - p1:+.1f} pp"
    d = (cua - p1) / p1 * 100
    return f"{d:+.0f}%"


def main():
    summary = json.loads((RESULT / "summary.json").read_text(encoding="utf-8"))
    p1, cua = summary["phase1"], summary["cua"]

    print("### 1. Executive Side-by-Side Summary\n")
    print("| Metric | Phase 1 Scraper | CUA Agent | % Difference / Delta |")
    print("| :--- | :--- | :--- | :--- |")
    print(f"| **Success Rate (%)** | {p1['success_rate_pct']}% ({p1['successes']}/20) "
          f"| {cua['success_rate_pct']}% ({cua['successes']}/20) "
          f"| {fmt_delta(p1['success_rate_pct'], cua['success_rate_pct'], pct=True)} |")
    print("| **Total URLs Tested** | 20 | 20 | 0% |")
    print(f"| **Avg. Runtime / Task (all runs)** | {p1['avg_runtime_s_all']} s "
          f"| {cua['avg_runtime_s_all']} s "
          f"| {fmt_delta(p1['avg_runtime_s_all'], cua['avg_runtime_s_all'])} |")
    print(f"| **Avg. Runtime / Successful Task** | {p1['avg_runtime_s_successful']} s "
          f"| {cua['avg_runtime_s_successful']} s "
          f"| {fmt_delta(p1['avg_runtime_s_successful'], cua['avg_runtime_s_successful'])} |")
    print(f"| **Avg. Steps / Task** | {p1['avg_steps_per_run']} "
          f"| {cua['avg_steps_per_run']} "
          f"| {fmt_delta(p1['avg_steps_per_run'], cua['avg_steps_per_run'])} |")
    print(f"| **Total Screenshots Taken** | 0 | {cua['total_screenshots']} | n/a |")
    print(f"| **Total Accumulated Cost** | ${p1['total_cost_usd']:.4f} "
          f"| ${cua['total_cost_usd']:.4f} | n/a (P1 = $0) |")
    cps = cua["cost_per_success_usd"]
    print(f"| **Cost per Success** | $0.0000 "
          f"| {'$' + format(cps, '.4f') if cps is not None else 'n/a'} | n/a (P1 = $0) |")
    print(f"| **Total Documents Downloaded** | {p1['total_files_downloaded']} "
          f"| {cua['total_files_downloaded']} "
          f"| {fmt_delta(p1['total_files_downloaded'], cua['total_files_downloaded'])} |")

    print("\n\n### 2. Per-URL Granular Breakdown\n")
    p1_rows = {r["url"]: r for r in load("phase1")}
    cua_rows = {r["url"]: r for r in load("cua")}
    urls = json.loads((RESULT / "selected_urls.json").read_text(encoding="utf-8"))

    print("| # | Domain | Annot. | P1 Outcome | P1 Steps | P1 Time (s) | P1 Cost "
          "| CUA Outcome | CUA Steps | CUA Shots | CUA Time (s) | CUA Cost |")
    print("| :- | :--- | :-- | :-- | :-: | :-: | :-: | :-- | :-: | :-: | :-: | :-: |")
    for i, e in enumerate(urls, 1):
        a = p1_rows.get(e["url"], {})
        b = cua_rows.get(e["url"], {})

        def oc(r):
            if not r:
                return "-"
            mark = "PASS" if r.get("outcome") == "success" else "FAIL"
            n = r.get("files_downloaded") or 0
            return f"{mark} ({n} f)"

        p1s = (a.get("steps") or {}).get("total", "—")
        cs = (b.get("steps") or {}).get("total", "—")
        print(f"| {i} | {e['domain']} | {e['annotated_state'][:4]} "
              f"| {oc(a)} | {p1s} | {a.get('runtime_s', '—')} | $0.00 "
              f"| {oc(b)} | {cs} | {b.get('screenshots_taken', '—')} "
              f"| {b.get('runtime_s', '—')} "
              f"| ${(b.get('cost_usd') or 0):.4f} |")


if __name__ == "__main__":
    main()
