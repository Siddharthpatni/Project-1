"""
benchmark_runner.py — Phase 1 Scraper vs CUA Agent side-by-side benchmark.

Orchestrates both frameworks over the same 20 URLs (selected_urls.json):
  * each URL runs in an isolated subprocess (phase1_worker.py / cua_worker.py)
  * hard wall-clock cap per URL; on timeout the whole process tree is killed
    and the output dir is rescued-scanned (files already downloaded still count)
  * results saved incrementally to results/phase1_results.json and
    results/cua_results.json, plus a flat results/all_runs.csv
  * CUA cost = tokens x live OpenRouter pricing weights for the exact model

Usage (from the scripts/ directory):
  python benchmark_runner.py --framework phase1
  python benchmark_runner.py --framework cua
  python benchmark_runner.py --framework both
  python benchmark_runner.py --aggregate-only
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

HERE = Path(__file__).parent          # scripts/
BASE = HERE.parent                    # benchmark root
RESULT_DIR = BASE / "results"
RUNS_DIR = BASE / "results" / "downloads"
LOGS_DIR = BASE / "logs"
SELECTED = BASE / "results" / "selected_urls.json"

PHASE1_CAP_S = 240      # per-URL wall-clock cap for Phase 1
CUA_CAP_S = 420         # hard external cap for CUA (worker's own cap is 390s)
CUA_MAX_STEPS = 25      # agent step budget per URL

# Live OpenRouter pricing for the exact model used (USD per token),
# fetched 2026-07-05 from https://openrouter.ai/api/v1/models and
# re-fetched at runtime when possible.
PRICING_FALLBACK = {
    "model": "google/gemini-3-flash-preview",
    "prompt": 0.0000005,      # $0.50 / 1M input tokens (incl. image tokens)
    "completion": 0.000003,   # $3.00 / 1M output tokens
}


def fetch_live_pricing(model_id: str) -> dict:
    try:
        import urllib.request
        with urllib.request.urlopen("https://openrouter.ai/api/v1/models", timeout=20) as r:
            data = json.load(r)
        for m in data.get("data", []):
            if m.get("id") == model_id:
                p = m.get("pricing", {})
                return {
                    "model": model_id,
                    "prompt": float(p.get("prompt") or PRICING_FALLBACK["prompt"]),
                    "completion": float(p.get("completion") or PRICING_FALLBACK["completion"]),
                }
    except Exception as e:
        print(f"[runner] live pricing fetch failed ({e}); using pinned weights")
    return dict(PRICING_FALLBACK)


def cua_cost_usd(tokens: dict, pricing: dict) -> float:
    # OpenRouter reports image/vision tokens inside prompt_tokens; the
    # image-token subset is tracked separately for reporting only.
    return round(tokens.get("prompt", 0) * pricing["prompt"]
                 + tokens.get("completion", 0) * pricing["completion"], 6)


def rescue_scan(outdir: Path) -> list[dict]:
    """Post-kill scan: count valid, deduped files that landed before timeout."""
    kept, seen = [], set()
    if not outdir.is_dir():
        return kept
    import hashlib
    for fp in sorted(outdir.rglob("*")):
        if not fp.is_file() or fp.suffix.lower() in (".crdownload", ".tmp", ".part", ".download"):
            continue
        try:
            size = fp.stat().st_size
            if size < 200:
                continue
            hdr = fp.read_bytes()[:512].lower()
            if b"<html" in hdr or b"<!doctype" in hdr:
                continue
            digest = hashlib.md5(fp.read_bytes()).hexdigest()
            if digest in seen:
                continue
            seen.add(digest)
            kept.append({"name": fp.name, "bytes": size})
        except OSError:
            continue
    return kept


def run_one(framework: str, idx: int, entry: dict, pricing: dict) -> dict:
    url = entry["url"]
    domain = entry["domain"]
    outdir = RUNS_DIR / framework / f"{idx:02d}_{domain.replace(':', '_')}"
    outdir.mkdir(parents=True, exist_ok=True)
    logfile = LOGS_DIR / f"{framework}_{idx:02d}.log"

    if framework == "phase1":
        cmd = [sys.executable, str(HERE / "phase1_worker.py"), url, str(outdir)]
        cap = PHASE1_CAP_S
    else:
        cmd = [sys.executable, str(HERE / "cua_worker.py"), url, str(outdir), str(CUA_MAX_STEPS)]
        cap = CUA_CAP_S

    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["ANONYMIZED_TELEMETRY"] = "false"
    env["BROWSER_USE_CLOUD_SYNC"] = "false"

    print(f"[runner] {framework} {idx:02d}/{20} {domain} (cap {cap}s)", flush=True)
    t0 = time.perf_counter()
    timed_out = False
    with open(logfile, "w", encoding="utf-8", errors="replace") as lf:
        proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT, env=env,
                                cwd=str(HERE))
        try:
            proc.wait(timeout=cap)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           capture_output=True)
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                pass
    wall = time.perf_counter() - t0

    # Parse the worker's result line
    result = None
    try:
        for line in logfile.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("@@RESULT@@"):
                result = json.loads(line[len("@@RESULT@@"):])
    except Exception:
        result = None

    if result is None:
        files = rescue_scan(outdir)
        result = {
            "framework": framework,
            "url": url,
            "domain": domain,
            "outcome": "success" if files else "failure",
            "files_downloaded": len(files),
            "files": files,
            "steps": {"total": None},
            "screenshots_taken": None,
            "runtime_s": round(wall, 3),
            "llm_tokens": {"prompt": 0, "completion": 0, "image": 0},
            "error": "hard timeout — process tree killed" if timed_out else "worker crashed (no result line)",
            "timed_out": timed_out,
        }

    result["wall_runtime_s"] = round(wall, 3)
    result["annotated_state"] = entry["annotated_state"]
    result["layout_class"] = entry["layout_class"]
    result["idx"] = idx
    if framework == "cua":
        result["cost_usd"] = cua_cost_usd(result.get("llm_tokens", {}), pricing)
        result["pricing_used"] = pricing
    else:
        result.setdefault("cost_usd", 0.0)  # no proxy/network costs in this setup

    status = result["outcome"].upper()
    print(f"[runner]   -> {status} files={result.get('files_downloaded', 0)} "
          f"runtime={result.get('runtime_s')}s cost=${result.get('cost_usd', 0):.4f}",
          flush=True)
    return result


def wait_for_network(max_wait_s: int = 900) -> bool:
    """Block until openrouter.ai resolves+responds; guards against benchmark
    runs silently burning while the machine is offline/asleep."""
    import urllib.request
    waited = 0
    while waited <= max_wait_s:
        try:
            req = urllib.request.Request("https://openrouter.ai/api/v1/models",
                                         method="HEAD")
            urllib.request.urlopen(req, timeout=10)
            return True
        except Exception:
            if waited == 0:
                print("[runner] network down — waiting for connectivity...", flush=True)
            time.sleep(30)
            waited += 30
    return False


def looks_like_network_casualty(framework: str, res: dict) -> bool:
    return (framework == "cua"
            and res.get("outcome") == "failure"
            and (res.get("llm_tokens") or {}).get("llm_calls", 0) == 0)


def run_framework(framework: str, entries: list[dict], pricing: dict):
    outfile = RESULT_DIR / f"{framework}_results.json"
    results = []
    if outfile.exists():
        results = json.loads(outfile.read_text(encoding="utf-8"))
    done_urls = {r["url"] for r in results}
    for idx, entry in enumerate(entries, 1):
        if entry["url"] in done_urls:
            print(f"[runner] {framework} {idx:02d} already done, skipping")
            continue
        if framework == "cua" and not wait_for_network():
            print("[runner] network still down after 15 min — aborting (resumable)")
            break
        res = run_one(framework, idx, entry, pricing)
        if looks_like_network_casualty(framework, res):
            print(f"[runner] {framework} {idx:02d} looks like a network casualty "
                  f"(0 LLM calls) — waiting for network and retrying once", flush=True)
            if wait_for_network():
                res = run_one(framework, idx, entry, pricing)
        results.append(res)
        outfile.write_text(json.dumps(results, indent=2, ensure_ascii=False),
                           encoding="utf-8")
    print(f"[runner] {framework} complete: {outfile}")


def aggregate():
    summary = {}
    rows_csv = []
    for fw in ("phase1", "cua"):
        f = RESULT_DIR / f"{fw}_results.json"
        if not f.exists():
            continue
        rows = json.loads(f.read_text(encoding="utf-8"))
        n = len(rows)
        succ = [r for r in rows if r["outcome"] == "success"]
        total_cost = sum(r.get("cost_usd") or 0 for r in rows)
        runtimes = [r.get("runtime_s") or r.get("wall_runtime_s") or 0 for r in rows]
        succ_runtimes = [r.get("runtime_s") or r.get("wall_runtime_s") or 0 for r in succ]
        steps = [(r.get("steps") or {}).get("total") for r in rows]
        steps = [s for s in steps if isinstance(s, (int, float))]
        shots = [r.get("screenshots_taken") for r in rows
                 if isinstance(r.get("screenshots_taken"), (int, float))]
        summary[fw] = {
            "urls_tested": n,
            "successes": len(succ),
            "success_rate_pct": round(100 * len(succ) / n, 1) if n else 0,
            "avg_runtime_s_all": round(sum(runtimes) / n, 1) if n else 0,
            "avg_runtime_s_successful": round(sum(succ_runtimes) / len(succ), 1) if succ else None,
            "avg_steps_per_run": round(sum(steps) / len(steps), 1) if steps else None,
            "total_screenshots": int(sum(shots)) if shots else 0,
            "total_cost_usd": round(total_cost, 4),
            "cost_per_success_usd": round(total_cost / len(succ), 4) if succ else None,
            "total_files_downloaded": sum(r.get("files_downloaded") or 0 for r in rows),
            "successes_on_simple": sum(1 for r in succ if r.get("layout_class") == "simple"),
            "successes_on_complex": sum(1 for r in succ if r.get("layout_class") == "complex"),
        }
        for r in rows:
            rows_csv.append({
                "framework": fw, "idx": r.get("idx"), "domain": r.get("domain"),
                "url": r.get("url"), "annotated_state": r.get("annotated_state"),
                "layout_class": r.get("layout_class"), "outcome": r.get("outcome"),
                "files_downloaded": r.get("files_downloaded"),
                "steps_total": (r.get("steps") or {}).get("total"),
                "screenshots": r.get("screenshots_taken"),
                "runtime_s": r.get("runtime_s"),
                "prompt_tokens": (r.get("llm_tokens") or {}).get("prompt", 0),
                "image_tokens": (r.get("llm_tokens") or {}).get("image", 0),
                "completion_tokens": (r.get("llm_tokens") or {}).get("completion", 0),
                "cost_usd": r.get("cost_usd"),
                "timed_out": r.get("timed_out", False),
                "error": (r.get("error") or "")[:200],
            })

    (RESULT_DIR / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8")
    if rows_csv:
        with open(RESULT_DIR / "all_runs.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows_csv[0].keys()))
            w.writeheader()
            w.writerows(rows_csv)
    print(json.dumps(summary, indent=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--framework", choices=["phase1", "cua", "both"], default="both")
    ap.add_argument("--aggregate-only", action="store_true")
    args = ap.parse_args()

    RESULT_DIR.mkdir(exist_ok=True)
    RUNS_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)

    if args.aggregate_only:
        aggregate()
        return

    entries = json.loads(SELECTED.read_text(encoding="utf-8"))
    assert len(entries) == 20, f"expected 20 selected URLs, got {len(entries)}"

    pricing = fetch_live_pricing(os.environ.get("CUA_MODEL",
                                                PRICING_FALLBACK["model"]))
    print(f"[runner] pricing: {pricing}")

    if args.framework in ("phase1", "both"):
        run_framework("phase1", entries, pricing)
    if args.framework in ("cua", "both"):
        if not os.environ.get("OPENROUTER_API_KEY"):
            print("[runner] ERROR: OPENROUTER_API_KEY not set — cannot run CUA")
            sys.exit(2)
        run_framework("cua", entries, pricing)

    aggregate()


if __name__ == "__main__":
    main()
