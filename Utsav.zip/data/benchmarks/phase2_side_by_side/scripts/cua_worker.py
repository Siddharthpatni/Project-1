"""
CUA (Computer Use Agent) worker — instrumented single-URL run of the
browser-use agent framework against the vision model configured via the
CUA_MODEL env var (served through OpenRouter). The task prompt matches the
production CUA agent for comparability.

Instrumentation:
  * token usage    — the LLM's ainvoke is wrapped; every ChatInvokeUsage is
                     accumulated (prompt / cached / image / completion tokens)
  * steps          — counted via the on_step_end callback (robust to timeout)
  * screenshots    — from AgentHistoryList.screenshots()/screenshot_paths(),
                     with steps as the vision-mode lower-bound fallback
  * downloads      — downloads dir scanned, partials skipped, HTML error pages
                     rejected, MD5-deduplicated (same standard as Phase 1)

Usage:  python cua_worker.py <url> <downloads_dir> [max_steps]
Env:    OPENROUTER_API_KEY (required), CUA_MODEL, CUA_TIMEOUT_S
Emits:  '@@RESULT@@{json}' on stdout as the last line.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
import time
from urllib.parse import urlparse

from browser_use import Agent, BrowserProfile
from browser_use.llm.openrouter.chat import ChatOpenRouter

DEFAULT_MODEL = "google/gemini-3-flash-preview"

USAGE = {"llm_calls": 0, "prompt_tokens": 0, "prompt_cached_tokens": 0,
         "prompt_image_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
STEP_COUNTER = {"steps": 0}


def build_agent_task(url: str) -> str:
    # Identical to the production CUA agent's task prompt for comparability.
    return f"""
ROLE: HIGH-PRECISION PROCUREMENT DATA ENGINEER

OBJECTIVE: Extract metadata and download all unique tender documents from: {url}

INSTRUCTIONS:
1. EXPLORATION & COOKIES:
   - Handle 'Accept All' / 'Zustimmen' cookie overlays immediately upon entry.
   - Look for tabs labeled "Dokumente", "Vergabeunterlagen", "Attachments".

2. DUPLICATE PREVENTION STRATEGY (CRITICAL):
   - Only click each unique document link EXACTLY ONCE. Do not repeatedly click.
   - If a file exists in multiple languages (e.g. DE / EN), ONLY trigger the download for the German (DE) version. Do not download the EN variant.

3. DOWNLOADING STRATEGY:
   - Prefer downloading via "Download All" / "Alle herunterladen" / ZIP mechanism if available.
   - If writing a script to find links, filter out anything that has "en" or "english" if a "de" counterpart exists.
   - Wait for all downloads to finish.

4. METADATA:
   - Extract the Tender Name, Deadline (YYYY-MM-DD), Organization, and Reference Number.

OUTPUT JSON FORMAT (STRICT):
{{
  "tender_name": "...",
  "deadline": "YYYY-MM-DD or unknown",
  "organization": "...",
  "reference_number": "...",
  "documents_detected": 0,
  "documents_downloaded": 0,
  "download_success": true,
  "status": "success",
  "reason": "..."
}}
"""


def wrap_llm_usage(llm):
    orig = llm.ainvoke

    async def wrapped(*args, **kwargs):
        res = await orig(*args, **kwargs)
        u = getattr(res, "usage", None)
        USAGE["llm_calls"] += 1
        if u is not None:
            USAGE["prompt_tokens"] += u.prompt_tokens or 0
            USAGE["prompt_cached_tokens"] += u.prompt_cached_tokens or 0
            USAGE["prompt_image_tokens"] += u.prompt_image_tokens or 0
            USAGE["completion_tokens"] += u.completion_tokens or 0
            USAGE["total_tokens"] += u.total_tokens or 0
        return res

    try:
        object.__setattr__(llm, "ainvoke", wrapped)
    except Exception:
        llm.ainvoke = wrapped
    return llm


PARTIAL_EXTS = (".crdownload", ".tmp", ".part", ".download")


def collect_downloads(downloads_path: str) -> tuple[list[dict], int]:
    """Validate + MD5-dedupe everything under downloads_path (recursive)."""
    kept, dupes, seen = [], 0, {}
    if not os.path.isdir(downloads_path):
        return kept, dupes
    for root, _dirs, files in os.walk(downloads_path):
        for fn in sorted(files, key=lambda x: (len(x), x)):
            fp = os.path.join(root, fn)
            if fn.endswith(PARTIAL_EXTS):
                continue
            try:
                size = os.path.getsize(fp)
                if size < 200:
                    continue
                with open(fp, "rb") as f:
                    hdr = f.read(512).lower()
                if b"<html" in hdr or b"<!doctype" in hdr:
                    continue
                h = hashlib.md5()
                with open(fp, "rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
                digest = h.hexdigest()
                if digest in seen:
                    dupes += 1
                    continue
                seen[digest] = fn
                kept.append({"name": fn, "bytes": size})
            except OSError:
                continue
    return kept, dupes


async def wait_for_downloads(downloads_path: str, timeout: int = 60):
    """Grace period before teardown: the downloads watchdog saves PDFs opened
    in viewer tabs asynchronously (no .crdownload marker), so an empty dir is
    given up to 15s to receive late files; partials are always waited out."""
    waited = 0
    while waited < timeout:
        if not os.path.isdir(downloads_path):
            return
        names = [f for _r, _d, fs in os.walk(downloads_path) for f in fs]
        if any(n.endswith(PARTIAL_EXTS) for n in names):
            await asyncio.sleep(5)
            waited += 5
        elif not names and waited < 15:
            await asyncio.sleep(5)
            waited += 5
        else:
            await asyncio.sleep(4)
            return


async def run(url: str, downloads_path: str, max_steps: int) -> dict:
    api_key = os.environ["OPENROUTER_API_KEY"]
    model = os.environ.get("CUA_MODEL", DEFAULT_MODEL)
    os.makedirs(downloads_path, exist_ok=True)

    llm = wrap_llm_usage(ChatOpenRouter(model=model, api_key=api_key))

    profile = BrowserProfile(
        headless=True,
        accept_downloads=True,
        downloads_path=downloads_path,
        auto_download_pdfs=True,
    )

    agent = Agent(task=build_agent_task(url), llm=llm, browser_profile=profile)

    async def on_step_end(agent_ref):
        STEP_COUNTER["steps"] += 1

    result: dict = {
        "framework": "cua",
        "url": url,
        "domain": urlparse(url).netloc,
        "model": model,
        "outcome": "failure",
        "timed_out": False,
        "agent_self_reported_success": None,
        "final_answer": "",
        "action_names": [],
        "error": "",
    }

    timeout_s = int(os.environ.get("CUA_TIMEOUT_S", "390"))
    t0 = time.perf_counter()
    history = None
    try:
        history = await asyncio.wait_for(
            agent.run(max_steps=max_steps, on_step_end=on_step_end),
            timeout=timeout_s,
        )
    except asyncio.TimeoutError:
        result["timed_out"] = True
        result["error"] = f"wall-clock cap {timeout_s}s hit"
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"

    # Let in-flight downloads finish while the browser is still alive,
    # THEN tear the session down.
    try:
        await asyncio.wait_for(wait_for_downloads(downloads_path, timeout=45), timeout=60)
    except Exception:
        pass
    try:
        session = getattr(agent, "browser_session", None)
        if session is not None:
            await asyncio.wait_for(session.kill(), timeout=20)
    except Exception:
        pass

    runtime = time.perf_counter() - t0

    steps = STEP_COUNTER["steps"]
    screenshots = 0
    if history is not None:
        try:
            steps = history.number_of_steps() or steps
        except Exception:
            pass
        for getter in ("screenshot_paths", "screenshots"):
            try:
                shots = getattr(history, getter)()
                if shots:
                    screenshots = len([s for s in shots if s])
                    break
            except Exception:
                continue
        try:
            result["agent_self_reported_success"] = bool(history.is_successful())
        except Exception:
            pass
        try:
            result["final_answer"] = (history.final_result() or "")[:600]
        except Exception:
            pass
        try:
            result["action_names"] = history.action_names()[:60]
        except Exception:
            pass
    if screenshots == 0 and steps:
        # vision mode sends one screenshot to the model per step
        screenshots = steps

    kept, dupes = collect_downloads(downloads_path)
    result.update({
        "outcome": "success" if kept else "failure",
        "files_downloaded": len(kept),
        "files": kept,
        "duplicate_files_removed": dupes,
        "steps": {"agent_steps": steps, "total": steps},
        "screenshots_taken": screenshots,
        "runtime_s": round(runtime, 3),
        "llm_tokens": {
            "prompt": USAGE["prompt_tokens"],
            "prompt_cached": USAGE["prompt_cached_tokens"],
            "image": USAGE["prompt_image_tokens"],
            "completion": USAGE["completion_tokens"],
            "total": USAGE["total_tokens"],
            "llm_calls": USAGE["llm_calls"],
        },
    })
    return result


def main():
    url = sys.argv[1]
    downloads_path = sys.argv[2]
    max_steps = int(sys.argv[3]) if len(sys.argv) > 3 else 25
    result = asyncio.run(run(url, downloads_path, max_steps))
    print("@@RESULT@@" + json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
