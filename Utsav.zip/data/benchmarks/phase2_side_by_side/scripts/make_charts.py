"""
Render the benchmark result charts as PNGs into ../results/charts/.

Charts:
  1. macro_comparison.png   — success rate / avg runtime / total cost, small multiples
  2. outcome_matrix.png     — per-URL pass-fail matrix for both frameworks
  3. cua_spend_breakdown.png — where the CUA budget went, by failure class

Palette: validated 2-slot categorical (blue/aqua) + reserved status colors;
every mark carries a direct value label (relief rule for the aqua slot).
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).parent          # scripts/
BASE = HERE.parent                    # benchmark root
RESULT = BASE / "results"
OUT = RESULT / "charts"

# palette roles (light mode, validated)
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
BASELINE = "#c3c2b7"
SERIES_P1 = "#2a78d6"    # categorical slot 1 — Phase 1
SERIES_CUA = "#1baf7a"   # categorical slot 2 — CUA
STATUS_GOOD = "#0ca30c"
STATUS_CRIT = "#d03b3b"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Segoe UI", "Arial", "DejaVu Sans"],
    "text.color": INK,
    "axes.edgecolor": BASELINE,
    "axes.labelcolor": INK2,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "savefig.dpi": 200,
})


def _despine(ax, keep_x=True):
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_visible(keep_x)
    ax.tick_params(length=0)


def macro_comparison(summary):
    p1, cua = summary["phase1"], summary["cua"]
    panels = [
        ("Success rate", [p1["success_rate_pct"], cua["success_rate_pct"]],
         lambda v: f"{v:.0f}%"),
        ("Avg runtime per URL", [p1["avg_runtime_s_all"], cua["avg_runtime_s_all"]],
         lambda v: f"{v:.1f} s"),
        ("Total cost, 20 URLs", [p1["total_cost_usd"], cua["total_cost_usd"]],
         lambda v: f"${v:.2f}"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.4))
    for ax, (title, vals, fmt) in zip(axes, panels):
        bars = ax.bar([0, 1], vals, width=0.52,
                      color=[SERIES_P1, SERIES_CUA], zorder=3)
        for rect, v in zip(bars, vals):
            ax.text(rect.get_x() + rect.get_width() / 2,
                    rect.get_height() + max(vals) * 0.03,
                    fmt(v), ha="center", va="bottom", fontsize=10, color=INK)
        ax.set_title(title, fontsize=11, color=INK, pad=12)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Phase 1", "CUA"], fontsize=10)
        ax.set_ylim(0, max(vals) * 1.22 or 1)
        ax.set_yticks([])
        ax.grid(False)
        _despine(ax)
    fig.suptitle("Phase 1 scraper vs CUA agent — 20-URL benchmark",
                 fontsize=13, color=INK, y=1.0)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(OUT / "macro_comparison.png", bbox_inches="tight")
    plt.close(fig)


def outcome_matrix(sel, p1_rows, cua_rows):
    n = len(sel)
    fig, ax = plt.subplots(figsize=(7.4, 0.42 * n + 1.6))
    ax.set_xlim(0, 2)
    ax.set_ylim(0, n)
    for i, e in enumerate(sel):
        y = n - 1 - i
        for col, rows in ((0, p1_rows), (1, cua_rows)):
            r = rows[e["url"]]
            ok = r["outcome"] == "success"
            color = STATUS_GOOD if ok else STATUS_CRIT
            ax.add_patch(plt.Rectangle((col + 0.02, y + 0.06), 0.96, 0.88,
                                       facecolor=color, alpha=0.16, zorder=2))
            files = r.get("files_downloaded") or 0
            label = f"PASS · {files} file{'s' if files != 1 else ''}" if ok else "FAIL"
            ax.text(col + 0.5, y + 0.5, label, ha="center", va="center",
                    fontsize=8.5, color=color, fontweight="bold", zorder=3)
        ax.text(-0.06, y + 0.5, f"{i + 1:>2}. {e['domain']}", ha="right",
                va="center", fontsize=8.5, color=INK2)
    ax.set_xticks([0.5, 1.5])
    ax.set_xticklabels(["Phase 1 scraper", "CUA agent"], fontsize=10, color=INK)
    ax.xaxis.set_ticks_position("top")
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)
    ax.set_title("Per-URL outcomes (validated document downloaded?)",
                 fontsize=12, color=INK, pad=30)
    fig.tight_layout()
    fig.savefig(OUT / "outcome_matrix.png", bbox_inches="tight")
    plt.close(fig)


def cua_spend_breakdown(cua_rows):
    # Failure classes per the findings section of the report (§3):
    dead = {6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}
    login = {1, 2}
    timeout = {5}
    classes = {
        "Tender no longer online": 0.0,
        "Login-walled portal": 0.0,
        "Successful downloads": 0.0,
        "Slow SPA (timeout)": 0.0,
        "Download missed (race)": 0.0,
    }
    for r in cua_rows.values():
        c = r.get("cost_usd") or 0
        if r["outcome"] == "success":
            classes["Successful downloads"] += c
        elif r["idx"] in dead:
            classes["Tender no longer online"] += c
        elif r["idx"] in login:
            classes["Login-walled portal"] += c
        elif r["idx"] in timeout:
            classes["Slow SPA (timeout)"] += c
        else:
            classes["Download missed (race)"] += c

    items = sorted(classes.items(), key=lambda kv: kv[1])
    total = sum(v for _, v in items)
    fig, ax = plt.subplots(figsize=(7.6, 3.2))
    ys = range(len(items))
    ax.barh(list(ys), [v for _, v in items], height=0.52,
            color=SERIES_P1, zorder=3)
    for y, (name, v) in zip(ys, items):
        ax.text(v + total * 0.012, y, f"${v:.2f} ({v / total:.0%})",
                va="center", fontsize=9.5, color=INK)
    ax.set_yticks(list(ys))
    ax.set_yticklabels([k for k, _ in items], fontsize=10, color=INK2)
    ax.set_xticks([])
    ax.set_xlim(0, max(v for _, v in items) * 1.30)
    _despine(ax, keep_x=False)
    ax.set_title(f"Where the CUA budget went (total ${total:.2f})",
                 fontsize=12, color=INK, pad=12)
    fig.tight_layout()
    fig.savefig(OUT / "cua_spend_breakdown.png", bbox_inches="tight")
    plt.close(fig)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    summary = json.loads((RESULT / "summary.json").read_text(encoding="utf-8"))
    sel = json.loads((RESULT / "selected_urls.json").read_text(encoding="utf-8"))
    p1_rows = {r["url"]: r for r in json.loads(
        (RESULT / "phase1_results.json").read_text(encoding="utf-8"))}
    cua_rows = {r["url"]: r for r in json.loads(
        (RESULT / "cua_results.json").read_text(encoding="utf-8"))}

    macro_comparison(summary)
    outcome_matrix(sel, p1_rows, cua_rows)
    cua_spend_breakdown(cua_rows)
    print("charts written to", OUT)


if __name__ == "__main__":
    main()
