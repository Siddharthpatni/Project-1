"""
Step 1 — Test selection for the Phase 1 vs CUA side-by-side benchmark.

Stratified, deterministic selection of 20 URLs from the annotated dataset:
  * covers the highest-volume portal domains (production-representative),
  * mixes annotated pipeline states:
      - COMPLETED   -> proxy for "simple / known-working layout"
      - FAILED      -> proxy for "complex / dynamic layout" (where CUA should help)
      - UNSUPPORTED -> hardest bucket
  * for each (domain, state) bucket picks the MOST RECENT row (created desc)
    so the tender is as likely as possible to still be online.

Output: ../results/selected_urls.json
"""
import csv
import json
from collections import defaultdict
from pathlib import Path

DATASET = r"C:\Users\Victus\Desktop\CUA_AGENT_SID\publications_b.csv"
OUT = Path(__file__).parent.parent / "results" / "selected_urls.json"

# (domain, state) buckets — 20 total, ordered by production volume.
BUCKETS = [
    ("www.evergabe.de", "COMPLETED"),
    ("www.evergabe.de", "FAILED"),
    ("www.subreport.de", "COMPLETED"),
    ("www.subreport.de", "FAILED"),
    ("vergabemarktplatz.brandenburg.de", "COMPLETED"),
    ("vergabe.niedersachsen.de", "COMPLETED"),
    ("bieterzugang.deutsche-evergabe.de", "FAILED"),
    ("www.evergabe.nrw.de", "COMPLETED"),
    ("www.vergabe-westfalen.de", "COMPLETED"),
    ("www.deutsches-ausschreibungsblatt.de", "FAILED"),
    ("www.had.de", "COMPLETED"),
    ("www.vergabe.metropoleruhr.de", "COMPLETED"),
    ("fbhh-evergabe.web.hamburg.de", "FAILED"),
    ("bi-medien.de", "COMPLETED"),
    ("www.tender24.de", "FAILED"),
    ("vergabe.landbw.de", "COMPLETED"),
    ("vergabekooperation.berlin", "FAILED"),
    ("www.evergabe.bayern.de", "COMPLETED"),
    ("vergabeportal-bw.de", "FAILED"),
    ("*", "UNSUPPORTED"),  # hardest bucket, any domain
]


def main():
    rows_by_bucket = defaultdict(list)
    seen_urls = set()
    with open(DATASET, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            url = row["url"].strip()
            if not url.startswith("http") or url in seen_urls:
                continue
            seen_urls.add(url)
            rows_by_bucket[(row["domain"], row["state"])].append(row)
            rows_by_bucket[("*", row["state"])].append(row)

    for key in rows_by_bucket:
        rows_by_bucket[key].sort(key=lambda r: r["created"], reverse=True)

    selected, used_urls = [], set()
    for domain, state in BUCKETS:
        for row in rows_by_bucket.get((domain, state), []):
            if row["url"] in used_urls:
                continue
            used_urls.add(row["url"])
            selected.append({
                "url": row["url"],
                "domain": row["domain"],
                "annotated_state": row["state"],
                "annotated_error": (row.get("error") or "")[:160],
                "created": row["created"],
                "layout_class": "simple" if row["state"] == "COMPLETED" else "complex",
            })
            break
        else:
            print(f"WARNING: no row for bucket ({domain}, {state})")

    assert len(selected) == 20, f"expected 20, got {len(selected)}"
    OUT.write_text(json.dumps(selected, indent=2), encoding="utf-8")
    n_simple = sum(1 for s in selected if s["layout_class"] == "simple")
    print(f"Selected {len(selected)} URLs -> {OUT}")
    print(f"  simple (COMPLETED): {n_simple} | complex (FAILED/UNSUPPORTED): {20 - n_simple}")
    for s in selected:
        print(f"  [{s['annotated_state']:11s}] {s['domain']}")


if __name__ == "__main__":
    main()
