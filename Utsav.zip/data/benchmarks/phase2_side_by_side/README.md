# Phase 2 Side-by-Side Benchmark — Phase 1 Scraper vs. CUA Agent

Comparative evaluation of the two document-retrieval frameworks over the **same 20
tender URLs** (20 distinct portal domains) drawn from the annotated evaluation
dataset. Full analysis: **[PHASE_2_BENCHMARK_REPORT.md](PHASE_2_BENCHMARK_REPORT.md)**.

## Headline results

| Metric | Phase 1 Scraper | CUA Agent |
| :--- | :--- | :--- |
| Success rate | 10% (2/20) | 15% (3/20) |
| Avg runtime / URL | 10.1 s | 154.5 s |
| Total cost (20 URLs) | $0.00 | $2.24 |
| Cost per success | $0.00 | $0.75 |
| Documents retrieved | 8 | 19 |

![Macro comparison](results/charts/macro_comparison.png)

Key context: 13 of the 20 sampled tenders had gone offline (visibility window
expired) between the dataset snapshot and the run date — no framework can succeed
on those. On reachable tenders, each framework won where its architecture
predicts: Phase 1 on template/link-based portals (fast, free), the CUA agent on
unsupported platforms and JS-heavy portals where templates drift.

## Folder layout

```
phase2_side_by_side/
├── README.md                     this file
├── PHASE_2_BENCHMARK_REPORT.md   full report: tables, findings, fallback rules
├── scripts/
│   ├── select_urls.py            stratified 20-URL sample from the dataset CSV
│   ├── benchmark_runner.py       orchestrator: subprocess isolation, caps,
│   │                             incremental saves, network guard, aggregation
│   ├── phase1_worker.py          scripted cascade (deterministic + heuristic)
│   ├── cua_worker.py             browser agent with token/step/screenshot metering
│   ├── make_report_tables.py     regenerates the report tables from raw results
│   └── make_charts.py            renders results/charts/*.png
├── results/
│   ├── summary.json              aggregated metrics for both frameworks
│   ├── phase1_results.json       per-URL raw metrics — Phase 1
│   ├── cua_results.json          per-URL raw metrics — CUA
│   ├── all_runs.csv              both frameworks, flat, one row per run
│   ├── selected_urls.json        the 20 sampled URLs with annotations
│   ├── report_tables.md          generated markdown tables
│   ├── charts/                   result charts (PNG)
│   └── downloads/                the actual documents each framework retrieved
└── logs/                         raw per-URL run logs (evidence trail)
```

## Reproducing

```
cd scripts
python select_urls.py                          # regenerate the sample (deterministic)
python benchmark_runner.py --framework phase1  # scripted cascade, no API key needed
set OPENROUTER_API_KEY=...                     # required for the CUA half
python benchmark_runner.py --framework cua
python benchmark_runner.py --aggregate-only    # recompute summary.json + all_runs.csv
python make_report_tables.py                   # tables from raw results
python make_charts.py                          # charts from raw results
```

Notes: runs are resumable (already-processed URLs are skipped); each URL executes
in an isolated subprocess with a hard wall-clock cap; the runner pauses when the
network drops and discards runs that never reached the model API. The CUA model
ID and its pricing weights are pinned in `cua_worker.py` / `benchmark_runner.py`.
