# Phase 2 Benchmark Report — Phase 1 Scraper vs. CUA Agent

**Run date:** 2026-07-06 · **Sample:** 20 tender URLs (20 distinct portal domains) from the annotated
evaluation dataset `publications_b.csv` (7,500 rows, 61 domains) · **Selection:** stratified by
production volume × annotated pipeline state — 11 `COMPLETED` (simple-layout proxy), 8 `FAILED` +
1 `UNSUPPORTED` (complex/dynamic-layout proxy), most-recent row per bucket to maximize tender liveness.

| Component | Configuration |
| :--- | :--- |
| **Phase 1 Scraper** | Scripted cascade, zero LLM calls: DETERMINISTIC stage (DTVP/NetServer URL construction + plain HTTP, port of `phase3_integration/deterministic.py`) → HEURISTIC stage (Playwright generic download heuristics, port of `phase0_manual/v1_reference.py`). Wall cap 240 s/URL. |
| **CUA Agent** | `browser-use` 0.12.5 agent (vision on, headless Chromium) driving an OpenRouter-hosted vision model — the exact model ID and pricing weights are pinned in `scripts/cua_worker.py` / `scripts/benchmark_runner.py`. Step budget 25, wall cap 420 s/URL. |
| **Cost weights** | Live OpenRouter pricing at run time: **$0.50 / 1M prompt tokens, $3.00 / 1M completion tokens** (screenshot/vision tokens are billed inside prompt tokens; the API reported no separate image-token split). Phase 1 uses no proxies → $0.00. |
| **Success criterion** | Identical for both: ≥ 1 validated document on disk (≥ 200 bytes, not an HTML error page, MD5-deduplicated). |
| **Artifacts** | `scripts/` (runner + workers), `results/` (raw JSON/CSV, charts, downloaded documents), `logs/` (per-URL run logs). See `README.md` for the layout. |

> **Data-integrity note:** two mid-run network outages (machine sleep/Wi-Fi loss) invalidated 17 CUA
> attempts (0 LLM calls, DNS failures). Those were **discarded and fully re-executed** — every number
> below comes from a run with live LLM connectivity (248 billed LLM calls; 0 zero-call rows).
> The runner now pauses on connectivity loss instead of burning runs.

---

![Macro comparison](results/charts/macro_comparison.png)

### 1. Executive Side-by-Side Summary

| Metric | Phase 1 Scraper | CUA Agent | % Difference / Delta |
| :--- | :--- | :--- | :--- |
| **Success Rate (%)** | 10.0% (2/20) | 15.0% (3/20) | +5.0 pp |
| **Total URLs Tested** | 20 | 20 | 0% |
| **Avg. Runtime / Task (all runs)** | 10.1 s | 154.5 s | +1,430% (CUA ~15× slower) |
| **Avg. Runtime / Successful Task** | 7.6 s | 161.4 s | +2,024% (CUA ~21× slower) |
| **Avg. Steps / Task** | 3.5 (nav+clicks+HTTP) | 12.4 (agent steps) | +254% |
| **Total Screenshots Taken** | 0 | 229 | n/a |
| **Total Accumulated Cost** | $0.0000 | $2.2376 | n/a (P1 = $0) |
| **Cost per Success** | $0.0000 | $0.7459 | n/a (P1 = $0) |
| **Total Documents Downloaded** | 8 | 19 | +138% |

Token detail (CUA): 3,848,371 prompt + 104,480 completion tokens across 248 LLM calls.
Cost-per-success math includes all failed-run burn: $2.2376 total ÷ 3 successes = **$0.746**.

**Headline:** on the *union* of both runs, 5 of 20 URLs yielded documents — Phase 1 and CUA overlap on
only one domain (subreport). CUA's two unique wins were exactly the hard cases (a DTVP variant Phase 1's
template missed, and an `UNSUPPORTED` platform), while Phase 1's win was cheaper, faster, and had
higher raw recall on the portal both could handle.

### 2. Per-URL Granular Breakdown

![Per-URL outcome matrix](results/charts/outcome_matrix.png)

Annot. = dataset annotation (COMP = COMPLETED/simple, FAIL = FAILED/complex, UNSU = UNSUPPORTED). f = validated files.

| # | Domain | Annot. | P1 Outcome | P1 Steps | P1 Time (s) | P1 Cost | CUA Outcome | CUA Steps | CUA Shots | CUA Time (s) | CUA Cost |
| :- | :--- | :-- | :-- | :-: | :-: | :-: | :-- | :-: | :-: | :-: | :-: |
| 1 | www.evergabe.de | COMP | FAIL (0 f) | 3 | 18.3 | $0.00 | FAIL (0 f) | 24 | 23 | 286.9 | $0.2262 |
| 2 | www.evergabe.de | FAIL | FAIL (0 f) | 3 | 16.3 | $0.00 | FAIL (0 f) | 24 | 23 | 260.3 | $0.2636 |
| 3 | www.subreport.de | COMP | PASS (4 f) | 5 | 7.4 | $0.00 | FAIL (0 f) | 6 | 5 | 72.4 | $0.0464 |
| 4 | www.subreport.de | FAIL | PASS (4 f) | 5 | 7.7 | $0.00 | PASS (1 f) | 11 | 10 | 98.6 | $0.1084 |
| 5 | vergabemarktplatz.brandenburg.de | COMP | FAIL (0 f) | 2 | 7.1 | $0.00 | FAIL (0 f) | 12 | 12 | 392.4 | $0.0757 |
| 6 | vergabe.niedersachsen.de | COMP | FAIL (0 f) | 2 | 7.1 | $0.00 | FAIL (0 f) | 15 | 14 | 160.8 | $0.1273 |
| 7 | bieterzugang.deutsche-evergabe.de | FAIL | FAIL (0 f) | 1 | 6.0 | $0.00 | FAIL (0 f) | 2 | 1 | 32.1 | $0.0101 |
| 8 | www.evergabe.nrw.de | COMP | FAIL (0 f) | 2 | 7.1 | $0.00 | PASS (2 f) | 21 | 20 | 190.2 | $0.1854 |
| 9 | www.vergabe-westfalen.de | COMP | FAIL (0 f) | 2 | 7.1 | $0.00 | FAIL (0 f) | 21 | 20 | 221.8 | $0.1921 |
| 10 | www.deutsches-ausschreibungsblatt.de | FAIL | FAIL (0 f) | 8 | 12.8 | $0.00 | FAIL (0 f) | 17 | 16 | 206.7 | $0.1497 |
| 11 | www.had.de | COMP | FAIL (0 f) | 2 | 16.9 | $0.00 | FAIL (0 f) | 20 | 19 | 205.5 | $0.1729 |
| 12 | www.vergabe.metropoleruhr.de | COMP | FAIL (0 f) | 2 | 7.1 | $0.00 | FAIL (0 f) | 21 | 20 | 214.7 | $0.1979 |
| 13 | fbhh-evergabe.web.hamburg.de | FAIL | FAIL (0 f) | 1 | 6.3 | $0.00 | FAIL (0 f) | 2 | 1 | 50.7 | $0.0100 |
| 14 | bi-medien.de | COMP | FAIL (0 f) | 3 | 16.7 | $0.00 | FAIL (0 f) | 6 | 5 | 82.5 | $0.0467 |
| 15 | www.tender24.de | FAIL | FAIL (0 f) | 8 | 11.8 | $0.00 | FAIL (0 f) | 7 | 6 | 95.4 | $0.0570 |
| 16 | vergabe.landbw.de | COMP | FAIL (0 f) | 8 | 12.3 | $0.00 | FAIL (0 f) | 2 | 1 | 38.8 | $0.0104 |
| 17 | vergabekooperation.berlin | FAIL | FAIL (0 f) | 8 | 12.7 | $0.00 | FAIL (0 f) | 2 | 1 | 32.3 | $0.0101 |
| 18 | www.evergabe.bayern.de | COMP | FAIL (0 f) | 1 | 5.9 | $0.00 | FAIL (0 f) | 2 | 1 | 44.7 | $0.0097 |
| 19 | vergabeportal-bw.de | FAIL | FAIL (0 f) | 2 | 7.0 | $0.00 | FAIL (0 f) | 23 | 22 | 207.2 | $0.2162 |
| 20 | s2c.mercell.com | UNSU | FAIL (0 f) | 1 | 7.5 | $0.00 | PASS (16 f) | 10 | 9 | 195.5 | $0.1217 |

---

### 3. Findings & Performance Analysis

#### 3.0 The dominant confound: tender liveness

The single biggest driver of both failure rates is **not scraping capability — it is that 13 of the 20
tenders no longer exist**. The dataset snapshot is from March 2026; German portals remove
Vergabeunterlagen when the *Sichtbarkeitszeitraum* (visibility window) expires. CUA's page-level
diagnosis confirmed this explicitly per URL (#6, #7, #9–#19): messages like *"Der
Sichtbarkeitszeitraum dieser Vergabe ist abgelaufen"*, *"das Verfahren ist nicht mehr verfügbar"*, or
hard 404s. On those 13 URLs **no framework can succeed** — the realistic ceiling on this sample was
~6–7/20, of which Phase 1 captured 2 and CUA captured 3. Any Phase 3 design must treat "tender dead"
as a first-class outcome, not a scraper failure.

#### 3.1 CUA strengths (where CUA succeeded and Phase 1 failed)

1. **Unsupported platforms — s2c.mercell.com (#20, 16 documents, $0.12, 10 steps).** Annotated
   `UNSUPPORTED` in production; Phase 1 has no template and its heuristics found zero candidates on the
   Mercell SPA. CUA navigated the UI and downloaded the complete annex set (PDF/DOCX/XLSX/DOC/ZIP,
   incl. a 598 KB instruction guide). This is the clearest possible CUA-fallback value case.
2. **Template drift on "supported" platforms — www.evergabe.nrw.de (#8, 2 files incl. the full 3.96 MB
   `Vergabeunterlagen_CXS7YYGYTWE1Q05X.zip`).** Root cause found: the URL's *notice* ID
   (`CXS7YYGYT7HX2GCV`) differs from the internal *project* ID (`CXS7YYGYTWE1Q05X`). Phase 1's
   deterministic ZIP template plugs in the notice ID → 404. CUA clicked through notice → project →
   download-all and retrieved the real ZIP. **Actionable for Phase 1:** add a notice-ID → project-ID
   resolution hop (one page fetch) to the DTVP deterministic branch; that alone could convert live
   DTVP-family notices without any LLM.
3. **Precise failure diagnosis.** On every dead tender, CUA returned the exact portal message and often
   the tender name/organization — high-value metadata for flagging stale DB rows. Phase 1 just times
   out silently. On cosinex-deeplink portals with unambiguous error pages (#7, #13, #16–#18) CUA
   failed *cheaply*: 2 steps, 32–51 s, ~$0.01.
4. **Document precision.** On subreport (#4) CUA downloaded exactly the one tender-relevant document
   (Bekanntmachung) and deliberately skipped EN variants; Phase 1's "4 files" on the same portal
   include 3 boilerplate PDFs (AGB, Datenschutzerklärung, ADV-Vereinbarung). CUA optimizes precision;
   Phase 1's raw recall numbers overstate its useful yield.

#### 3.2 Phase 1 strengths (where Phase 1 outperformed CUA)

1. **Speed: 15–21× faster.** Median ~8 s/URL vs ~155 s. Successes completed in 7.4–7.7 s vs 98–196 s.
2. **Cost: structurally $0.** No tokens, no screenshots, no per-run cloud spend. At production volume
   (7,500 rows/quarter in this dataset) a CUA-only approach at the observed $0.112/URL average would
   cost ~$840/quarter; Phase 1 costs nothing beyond compute.
3. **Higher recall where its heuristics fit — subreport (#3, #4: 4 files vs CUA's 0–1).** The GWT
   portal exposes direct links Phase 1 clicks reliably; it also grabbed the same core document CUA got.
4. **Determinism.** Phase 1 produced identical results on repeated runs. CUA was *nondeterministic on
   the identical URL*: subreport #3 succeeded in a pre-run validation but failed in the recorded run —
   the download click opens a PDF viewer tab and the async capture sometimes misses the teardown
   window (observed success ratio ~2/3 on this flow).
5. **Cheap definitive failure.** Phase 1's failures cost $0 and ~10 s, so running it first is nearly
   free even when it loses.

#### 3.3 CUA weaknesses observed (cost-control implications)

![CUA spend breakdown](results/charts/cua_spend_breakdown.png)

- **Runaway exploration on dead tenders:** on #9–#12 and #19 the agent, finding the tender gone,
  proceeded to search *other* portals and even external search engines — 17–23 steps and $0.15–$0.22
  per URL for zero possible yield. **$1.21 of the $2.24 total (54%) was burned on tenders that no
  longer exist**, and another $0.49 (22%) on the two evergabe.de URLs where documents sit behind
  registration/login and the agent exhausted its 24-step budget searching.
- **Step-budget exhaustion pattern:** every run that reached 20+ steps except one (#8) ended in failure;
  successes clustered at 10–21 steps.
- **Timeout tail:** brandenburg (#5) hit the 390 s internal cap on a slow SPA.

---

### 4. Phase 3 Fallback Logic Recommendations

- **Condition A (Trigger Phase 1 First — always):** run the scripted cascade on *every* URL, prefixed
  by a **liveness probe** (1 HTTP GET; classify `404` / "Sichtbarkeitszeitraum … abgelaufen" /
  "Verfahren ist nicht mehr verfügbar" / "Angaben sind nicht korrekt" → outcome `EXPIRED`, stop, flag
  the DB row — do **not** escalate). Phase 1 first is justified by cost ($0), speed (~10 s), and its
  determinism; on this sample it resolves subreport-class portals outright. Fix the DTVP branch with
  the notice-ID → project-ID resolution hop found in §3.1(2) before measuring Phase 1 again.

- **Condition B (Escalate to CUA):** only when **all** of: (a) Phase 1 failed with a *live* page
  (liveness probe passed — page 200s without a dead-tender marker); (b) the failure class is
  CUA-addressable: platform `UNSUPPORTED`/unknown (mercell-class), JS-heavy SPA where heuristics found
  0 candidates, or deterministic-template 404 on a live notice (nrw-class); and (c) the domain is not
  on a known login-wall list (evergabe.de-class URLs need credentials, not vision — CUA burned $0.49
  there for nothing). Had this gate been active, CUA spend on this run would have dropped from $2.24
  to ≈ $0.55 with zero lost successes (−75%).

- **Cost/Performance Optimization Threshold:** per-URL: **max 15 agent steps** (raise to 22 only for
  domains with a prior CUA success), **300 s wall cap**, **$0.30 hard cost cap** (max observed success
  cost was $0.19); instruct the agent to emit `TENDER_EXPIRED` and stop at the first dead-tender
  marker, and forbid navigation off the target domain (kills the search-engine wandering that caused
  54% of spend). Fleet level: daily CUA budget alarm (e.g. $25/day ≈ 220 escalations) and a
  **route-learning hook** — persist each CUA success's action path into the Phase 3 scraper registry
  so the *second* visit to that platform is scripted and free.

---

### Verification Checklist

1. **All 20 URLs processed by both systems** — 20/20 rows in `phase1_results.json` and
   `cua_results.json`; no skips. Network-outage casualties were discarded and fully re-executed, not
   imputed (final CUA data: 248 billed LLM calls, zero rows with 0 LLM calls).
2. **Cost-per-success includes failure burn** — $2.2376 total spend (17 failures included) ÷ 3
   successes = $0.7459.
3. **Report + raw logs saved to workspace** — this file, with
   raw JSON/CSV/logs/downloads, under `data/benchmarks/phase2_side_by_side/`.
