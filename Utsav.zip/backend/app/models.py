"""
SQLAlchemy ORM models.

Tables:
- Job              : a scrape request (list of URLs) submitted by a client
- JobItem          : one URL within a job, with per-URL status and strategy used
- Document         : a downloaded tender document (stored in S3)
- ScraperTemplate  : a reusable scraper (either manually written or LLM-generated)
- EvaluationRun    : a row in the phase-1 benchmark table
- AgentRun         : a row in the phase-2 CUA benchmark table
- AuditLog         : append-only structured event log for all system operations
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum as PyEnum

from sqlalchemy import JSON, DateTime, Enum, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class JobStatus(str, PyEnum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"


class Strategy(str, PyEnum):
    MANUAL = "manual_scraper"
    EXISTING = "existing_scraper"
    DETERMINISTIC = "deterministic_template"
    ADAPTIVE = "adaptive_universal"  # country/language-agnostic heuristic scraper (free)
    LLM_GENERATED = "llm_generated_scraper"
    LEARNED_ROUTE = "learned_route"  # replay a route the CUA proved works (cheap)
    CUA = "computer_use_agent"
    NONE = "none"


class Job(Base):
    __tablename__ = "jobs"

    id:         Mapped[str]      = mapped_column(String, primary_key=True, default=_uuid)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    status:     Mapped[str]      = mapped_column(String, default=JobStatus.PENDING.value)
    submitted_by: Mapped[str | None] = mapped_column(String, nullable=True)
    total_urls:   Mapped[int]  = mapped_column(Integer, default=0)
    completed:    Mapped[int]  = mapped_column(Integer, default=0)
    cost_usd:     Mapped[float] = mapped_column(Float, default=0.0)

    items: Mapped[list["JobItem"]] = relationship(back_populates="job", cascade="all, delete-orphan")


class JobItem(Base):
    __tablename__ = "job_items"

    id:       Mapped[str]       = mapped_column(String, primary_key=True, default=_uuid)
    job_id:   Mapped[str]       = mapped_column(ForeignKey("jobs.id"))
    url:      Mapped[str]       = mapped_column(Text)
    domain:   Mapped[str]       = mapped_column(String, index=True)
    status:   Mapped[str]       = mapped_column(String, default=JobStatus.PENDING.value)
    strategy: Mapped[str]       = mapped_column(String, default=Strategy.NONE.value)
    iterations: Mapped[int]     = mapped_column(Integer, default=0)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    runtime_seconds: Mapped[float]    = mapped_column(Float, default=0.0)

    # Top-level failure category from security.classify_error — populated on
    # final failure so the UI / DB queries can group/filter by failure reason.
    failure_category: Mapped[str | None] = mapped_column(String, nullable=True, index=True)

    # Full cascade attempt chain — every strategy tried, its outcome, error, and timing.
    # Stored as JSON list of {strategy, success, downloaded, error, duration_s, ts}
    attempts_detail: Mapped[list] = mapped_column(JSON, default=list)

    # ── Public tender-directory projection ──────────────────────────────────
    # A successful JobItem *is* one published tender. These three columns are a
    # denormalized projection of the most-queried extracted fields (kept in
    # sync by the deep extractor; ExtractionRecord.fields_json stays the source
    # of truth). They exist so the public browse-by-domain directory can filter
    # "currently open" and sort "soonest-closing" with a real index instead of
    # parsing JSON at query time. All nullable — extraction may be absent or a
    # field may not have been found.
    tender_title:     Mapped[str | None]      = mapped_column(String, nullable=True)
    tender_reference: Mapped[str | None]      = mapped_column(String, nullable=True)
    # Parsed submission deadline. NULL = unknown (treated as still-open, never as
    # expired). A past value marks the tender expired and hides it from the directory.
    deadline:         Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    job: Mapped[Job] = relationship(back_populates="items")
    documents: Mapped[list["Document"]] = relationship(back_populates="job_item", cascade="all, delete-orphan")

    # Composite index for the directory queries: group/filter by domain, restrict
    # to published (status) tenders, and range-filter / order by deadline.
    __table_args__ = (
        Index("ix_job_items_directory", "domain", "status", "deadline"),
    )


class Document(Base):
    __tablename__ = "documents"

    id:          Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    job_item_id: Mapped[str] = mapped_column(ForeignKey("job_items.id"))
    filename:    Mapped[str] = mapped_column(String)
    s3_key:      Mapped[str] = mapped_column(String)
    mime_type:   Mapped[str] = mapped_column(String)
    size_bytes:  Mapped[int] = mapped_column(Integer, default=0)
    version:     Mapped[int] = mapped_column(Integer, default=1)
    checksum:    Mapped[str] = mapped_column(String, default="")
    created_at:  Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

    job_item: Mapped[JobItem] = relationship(back_populates="documents")


class ScraperTemplate(Base):
    """A reusable scraper keyed by domain (Phase 3 registry)."""
    __tablename__ = "scraper_templates"

    id:       Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    domain:   Mapped[str] = mapped_column(String, unique=True, index=True)
    code:     Mapped[str] = mapped_column(Text)
    language: Mapped[str] = mapped_column(String, default="python")
    source:   Mapped[str] = mapped_column(String, default="llm")  # llm | manual
    platform: Mapped[str | None] = mapped_column(String, nullable=True)  # e.g. "netserver", "dtvp"
    route_used: Mapped[bool] = mapped_column(default=False)  # was route-guided generation used?
    # CUA interaction trace stored as a text summary. Populated whenever the
    # CUA fallback runs for this domain (success or failure) so future LLM
    # generation can use it as verified navigation knowledge.
    cua_hint:      Mapped[str | None] = mapped_column(Text, nullable=True)
    # Replayable navigation route learned from a CUA-only success (set by the
    # CUA route learner when the agent succeeded after every cheaper strategy
    # failed). Serialized LearnedRoute — replayed cheaply by the LEARNED_ROUTE
    # strategy on future visits to this domain (no LLM, no vision, no full CUA).
    learned_route: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    success_count: Mapped[int] = mapped_column(Integer, default=0)
    failure_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_runtime:   Mapped[float] = mapped_column(Float, default=0.0)
    created_at:    Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at:    Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class EvaluationRun(Base):
    """A phase-1 benchmark row: one model × one URL × one attempt."""
    __tablename__ = "evaluation_runs"

    id:             Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    created_at:     Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    model:          Mapped[str] = mapped_column(String, index=True)
    url:            Mapped[str] = mapped_column(Text)
    expected_docs:  Mapped[int] = mapped_column(Integer, default=0)
    downloaded_docs: Mapped[int] = mapped_column(Integer, default=0)
    success:        Mapped[bool] = mapped_column(default=False)
    iterations:     Mapped[int] = mapped_column(Integer, default=0)
    runtime_seconds: Mapped[float] = mapped_column(Float, default=0.0)
    cost_usd:       Mapped[float] = mapped_column(Float, default=0.0)
    notes:          Mapped[str | None] = mapped_column(Text, nullable=True)


class AgentRun(Base):
    """A phase-2 CUA benchmark row."""
    __tablename__ = "agent_runs"

    id:         Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    agent_name: Mapped[str] = mapped_column(String, index=True)
    url:        Mapped[str] = mapped_column(Text)
    steps:      Mapped[int] = mapped_column(Integer, default=0)
    success:    Mapped[bool] = mapped_column(default=False)
    runtime_seconds: Mapped[float] = mapped_column(Float, default=0.0)
    cost_usd:   Mapped[float] = mapped_column(Float, default=0.0)
    trace:      Mapped[dict]  = mapped_column(JSON, default=dict)


class ExtractionRecord(Base):
    """Stores structured fields extracted from a job item's downloaded documents."""
    __tablename__ = "extraction_records"

    id:              Mapped[str]      = mapped_column(String, primary_key=True, default=_uuid)
    job_item_id:     Mapped[str]      = mapped_column(ForeignKey("job_items.id"), unique=True, index=True)
    source_url:      Mapped[str]      = mapped_column(Text, default="")
    fields_json:     Mapped[str]      = mapped_column(Text, default="{}")
    docs_parsed:     Mapped[int]      = mapped_column(Integer, default=0)
    runtime_seconds: Mapped[float]    = mapped_column(Float, default=0.0)
    created_at:      Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at:      Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    job_item: Mapped["JobItem"] = relationship("JobItem", foreign_keys=[job_item_id])


class AuditLog(Base):
    """
    Append-only structured event log.

    Every significant pipeline event, error, recovery action, and security
    alert is written here so ops can replay the exact sequence that led to
    any outcome. Never UPDATE or DELETE rows — only INSERT.
    """
    __tablename__ = "audit_logs"

    id:          Mapped[str]      = mapped_column(String, primary_key=True, default=_uuid)
    created_at:  Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    level:       Mapped[str]      = mapped_column(String, default="info")   # info|warning|error|critical
    event_type:  Mapped[str]      = mapped_column(String, index=True)        # pipeline.start, strategy.attempt, …
    job_id:      Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    item_id:     Mapped[str | None] = mapped_column(String, nullable=True)
    domain:      Mapped[str | None] = mapped_column(String, nullable=True)
    url:         Mapped[str | None] = mapped_column(Text,   nullable=True)
    strategy:    Mapped[str | None] = mapped_column(String, nullable=True)
    message:     Mapped[str]      = mapped_column(Text, default="")
    extra:       Mapped[dict]     = mapped_column(JSON, default=dict)        # arbitrary extra fields (metadata reserved by SQLAlchemy)
