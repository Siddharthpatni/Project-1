#!/usr/bin/env python3
"""
Vergabepilot.AI — Main CLI Entry Point
=======================================

Usage examples:

  # Process a single URL
  python main.py --url "https://www.evergabe.de/..." --api-key sk-or-...

  # Process from CSV (column index 4 = URL)
  python main.py --input publications.csv --limit 10

  # Use CUA-only (skip LLM scraper generation)
  python main.py --url "https://..." --cua-only

  # Use LLM scraper only (no browser agent fallback)
  python main.py --input urls.csv --scraper-only

  # Headless mode (background browser)
  python main.py --input urls.csv --headless

Environment:
  OPENROUTER_API_KEY  — your OpenRouter API key (or pass via --api-key)
"""

import argparse
import asyncio
import csv
import logging
import os
import sys
from dotenv import load_dotenv

load_dotenv()

# ── Logging ────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler("logs/vergabepilot.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("vergabepilot.main")


def _load_urls_from_csv(path: str, url_column: int = 4) -> list[str]:
    urls = []
    with open(path, encoding="utf-8") as f:
        for row in csv.reader(f):
            if len(row) > url_column:
                u = row[url_column].strip()
                if u.startswith("http"):
                    urls.append(u)
    return urls


async def main(args: argparse.Namespace) -> None:
    from vergabepilot.config import Config
    from vergabepilot.core.pipeline import Pipeline

    api_key = args.api_key or os.getenv("OPENROUTER_API_KEY", "")
    if not api_key:
        log.error("No API key. Set OPENROUTER_API_KEY or pass --api-key.")
        sys.exit(1)

    cfg = Config(
        openrouter_api_key   = api_key,
        generator_model      = args.generator_model,
        cua_model            = args.cua_model,
        max_generator_retries= args.retries,
        scraper_timeout_sec  = args.scraper_timeout,
        cua_max_steps        = args.cua_steps,
        headless             = args.headless,
        url_limit            = args.limit,
        base_download_dir    = args.download_dir,
        result_dir           = args.result_dir,
        scraper_cache_dir    = args.cache_dir,
    )

    # ── Collect URLs ──────────────────────────────────────────────────
    if args.url:
        urls = [args.url.strip()]
        log.info("Single URL mode")
    elif args.input:
        if not os.path.exists(args.input):
            log.error(f"Input file not found: {args.input}")
            sys.exit(1)
        urls = _load_urls_from_csv(args.input, url_column=args.url_column)
        log.info(f"Loaded {len(urls)} URLs from {args.input}")
    else:
        log.error("Provide --url or --input.")
        sys.exit(1)

    if cfg.url_limit > 0:
        urls = urls[: cfg.url_limit]
        log.info(f"Limiting to {len(urls)} URLs")

    # ── Override pipeline mode ────────────────────────────────────────
    pipeline = Pipeline(cfg)

    if args.cua_only:
        log.info("Mode: CUA-only (skipping LLM scraper)")
        from vergabepilot.utils.results import SessionStats, save_results, ScrapeResult
        stats   = SessionStats()
        results = []
        for i, url in enumerate(urls, 1):
            log.info(f"CUA [{i}/{len(urls)}]: {url}")
            import hashlib, os as _os
            from urllib.parse import urlparse
            domain    = urlparse(url).netloc
            url_hash  = hashlib.md5(url.encode()).hexdigest()[:8]
            out_dir   = _os.path.join(cfg.base_download_dir, domain, url_hash)
            r = await pipeline.cua.run(url, out_dir)
            results.append(r)
            stats.update(r)
            print(f"  [{i:>3}/{len(urls)}] {r.status.upper():<8} | docs={r.documents_downloaded}")
        stats.print_summary()
        save_results(results, cfg.result_dir)

    elif args.scraper_only:
        log.info("Mode: LLM-scraper-only (no CUA fallback)")
        from vergabepilot.utils.results import (
            SessionStats, save_results, ScrapeResult
        )
        from vergabepilot.utils.dedup import Deduplicator
        import hashlib, os as _os
        from urllib.parse import urlparse

        stats   = SessionStats()
        results = []
        for i, url in enumerate(urls, 1):
            log.info(f"GEN [{i}/{len(urls)}]: {url}")
            domain    = urlparse(url).netloc
            url_hash  = hashlib.md5(url.encode()).hexdigest()[:8]
            out_dir   = _os.path.join(cfg.base_download_dir, domain, url_hash)
            _os.makedirs(out_dir, exist_ok=True)

            dedup = Deduplicator(out_dir, cfg.min_file_size_bytes)
            dedup.snapshot_before()

            ok, meta, iters = await pipeline.generator.run(url, out_dir)
            unique = dedup.resolve()

            r = ScrapeResult(url=url, domain=domain, approach_used="llm_scraper",
                             scraper_iterations=iters)
            r.documents_downloaded = len(unique)
            r.downloaded_docs      = "; ".join(unique)
            if meta:
                for k, v in meta.items():
                    if hasattr(r, k) and k != "documents_downloaded":
                        setattr(r, k, v)
            r.duplicates_removed = max(
                0, meta.get("documents_downloaded", 0) - len(unique)
            ) if meta else 0
            r.finalize()
            results.append(r)
            stats.update(r)
            print(
                f"  [{i:>3}/{len(urls)}] {r.status.upper():<8} | "
                f"docs={r.documents_downloaded} | dedup={r.duplicates_removed} | "
                f"iters={iters}"
            )

        stats.print_summary()
        save_results(results, cfg.result_dir)

    else:
        # Full pipeline: LLM scraper → CUA fallback
        await pipeline.run_batch(urls)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Vergabepilot.AI — Agentic Tender Document Scraper",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # ── Input ──────────────────────────────────────────────────────────
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--url",   help="Single URL to process")
    src.add_argument("--input", help="CSV file with URLs")
    parser.add_argument("--url-column", type=int, default=4,
                        help="0-based column index for URL in CSV (default: 4)")
    parser.add_argument("-n", "--limit", type=int, default=0,
                        help="Max URLs to process (0 = all)")

    # ── API / Models ───────────────────────────────────────────────────
    parser.add_argument("--api-key", default=None, help="OpenRouter API key")
    parser.add_argument("--generator-model",
                        default="google/gemini-2.5-flash-lite",
                        help="LLM for scraper generation")
    parser.add_argument("--cua-model",
                        default="google/gemini-2.5-flash-lite",
                        help="LLM for CUA agent")

    # ── Pipeline mode ──────────────────────────────────────────────────
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--cua-only",     action="store_true",
                      help="Use CUA agent only (skip LLM scraper)")
    mode.add_argument("--scraper-only", action="store_true",
                      help="Use LLM scraper only (no CUA fallback)")

    # ── Tuning ────────────────────────────────────────────────────────
    parser.add_argument("--retries",         type=int, default=3,
                        help="LLM scraper generation retries")
    parser.add_argument("--scraper-timeout", type=int, default=120,
                        help="Max seconds for generated scraper to run")
    parser.add_argument("--cua-steps",       type=int, default=50,
                        help="Max steps for CUA agent")
    parser.add_argument("--headless", action="store_true",
                        help="Run browser in headless/background mode")

    # ── Paths ──────────────────────────────────────────────────────────
    parser.add_argument("--download-dir", default="downloads")
    parser.add_argument("--result-dir",   default="result")
    parser.add_argument("--cache-dir",    default="scraper_cache")

    args = parser.parse_args()
    asyncio.run(main(args))
