
class Config:
    def __init__(self,
                 openrouter_api_key,
                 generator_model,
                 cua_model,
                 max_generator_retries,
                 scraper_timeout_sec,
                 cua_max_steps,
                 headless,
                 url_limit,
                 base_download_dir,
                 result_dir,
                 scraper_cache_dir):

        self.openrouter_api_key = openrouter_api_key
        self.generator_model = generator_model
        self.cua_model = cua_model
        self.max_generator_retries = max_generator_retries
        self.scraper_timeout_sec = scraper_timeout_sec
        self.cua_max_steps = cua_max_steps
        self.headless = headless
        self.url_limit = url_limit
        self.base_download_dir = base_download_dir
        self.result_dir = result_dir
        self.scraper_cache_dir = scraper_cache_dir

        self.cua_max_actions_per_step = 40
        self.nav_timeout = 60
        self.download_timeout = 300
        self.min_file_size_bytes = 512
