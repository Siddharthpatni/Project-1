"""
Vergabepilot.AI — CUA Agent (Phase 2 / Fallback)
=================================================
Computer-Use Agent using browser-use + LLM.
Key improvements over base version:
  - Deduplication integrated (hash + name)
  - Waits for all .crdownload/.part files to finish
  - JSON extraction robust (handles extra text around JSON)
  - Returns structured ScrapeResult
"""

import asyncio
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from vergabepilot.utils.dedup import Deduplicator
from vergabepilot.utils.results import ScrapeResult

log = logging.getLogger("vergabepilot.cua")


# ── Agent task prompt ─────────────────────────────────────────────────────────

def _build_task(url: str) -> str:
    return f"""
YOU ARE A HIGH-PRECISION PROCUREMENT AGENT.

════════════════════════════
TARGET URL
════════════════════════════
{url}

════════════════════════════
MANDATORY RULES
════════════════════════════
- DO NOT STOP until ALL documents are found and downloaded
- ALWAYS SCROLL MULTIPLE TIMES in document sections
- ALWAYS VERIFY: downloaded_count == detected_count before finishing
- NEVER assume completion early
- DO NOT download the same file twice

════════════════════════════
EXECUTION STEPS
════════════════════════════

STEP 1 – OPEN PAGE & HANDLE COOKIES
  → Click: Accept / Akzeptieren / Allow all / Alle akzeptieren

STEP 2 – EXTRACT TENDER METADATA (do this early)
  → Capture: tender title, deadline, organization, reference number

STEP 3 – NAVIGATE TO FULL TENDER
  IF list view: click title / "Details" / "Ausschreibung"
  IF portal required: click "Vergabeportal" / "Bieterzugang" / "Ausschreibungsunterlagen"

STEP 4 – FIND DOCUMENT SECTION (thorough search)
  Look for tabs/sections named:
    Dokumente | Vergabeunterlagen | Downloads | Anhänge | Unterlagen | Attachments
  IF not visible:
    → Click all tabs
    → Scroll down completely
    → Expand any "Mehr anzeigen" / "More" buttons
    → Check for pagination

STEP 5 – COUNT DOCUMENTS
  → Count all visible downloadable files → store as EXPECTED_COUNT

STEP 6 – DOWNLOAD ALL DOCUMENTS
  First try: "Download all" / "Alle herunterladen" / ZIP button
  If not available, loop:
    FOR EACH FILE:
      → Click filename / download icon
      → Wait for download to register
      → Track the filename
      → DO NOT re-click files already downloaded
  After each download: re-check if EXPECTED_COUNT is reached

STEP 7 – DEDUPLICATION CHECK
  → Do not click a file you have already downloaded
  → If two files have identical names, skip the second

STEP 8 – VALIDATION
  IF downloaded_count == expected_count → status = "success"
  ELSE → status = "partial", explain what is missing in reason

════════════════════════════
OUTPUT — STRICT JSON ONLY
════════════════════════════
{{
  "tender_name": "string",
  "deadline": "YYYY-MM-DD or unknown",
  "organization": "string or unknown",
  "reference_number": "string or unknown",
  "documents_detected": <number>,
  "documents_downloaded": <number>,
  "missing_documents": <number>,
  "duplicate_files": <number>,
  "pages_visited": <number>,
  "clicks_performed": <number>,
  "download_success": true/false,
  "status": "success | partial | failed",
  "reason": "clear explanation"
}}

OUTPUT MUST BE ONLY THE JSON OBJECT — NO OTHER TEXT.
"""


def _extract_json(text: str) -> Optional[dict]:
    """Robustly extract JSON from agent output even if there's surrounding text."""
    if not text:
        return None
    # Try full parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Find outermost { ... }
    start = text.find("{")
    end   = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            return json.loads(text[start:end])
        except json.JSONDecodeError:
            pass
    return None


# ── CUA Runner ────────────────────────────────────────────────────────────────

class CUAAgent:
    def __init__(self, api_key: str, model: str, headless: bool = False,
                 max_steps: int = 50, max_actions: int = 40,
                 nav_timeout: float = 60.0, dl_timeout: float = 300.0):
        self.api_key   = api_key
        self.model     = model
        self.headless  = headless
        self.max_steps = max_steps
        self.max_actions = max_actions
        self.nav_timeout = nav_timeout
        self.dl_timeout  = dl_timeout

    # ------------------------------------------------------------------
    async def run(self, url: str, output_dir: str) -> ScrapeResult:
        """Run CUA for one URL and return a structured result."""
        # Import here so the rest of the package works even without browser-use
        try:
            from browser_use import Agent, Browser
            from browser_use.llm.openrouter.chat import ChatOpenRouter
        except ImportError as e:
            log.error(f"browser-use not installed: {e}")
            r = ScrapeResult(url=url, domain=urlparse(url).netloc)
            r.status = "error"
            r.reason = "browser-use package not installed"
            return r

        domain    = urlparse(url).netloc
        url_hash  = __import__("hashlib").md5(url.encode()).hexdigest()[:8]
        os.makedirs(output_dir, exist_ok=True)

        dedup = Deduplicator(output_dir)
        dedup.snapshot_before()

        result = ScrapeResult(
            url=url, domain=domain, approach_used="cua_agent"
        )

        llm     = ChatOpenRouter(model=self.model, api_key=self.api_key)
        browser = Browser(headless=self.headless, downloads_path=output_dir)
        agent   = Agent(
            task=_build_task(url),
            llm=llm,
            browser=browser,
            max_steps=self.max_steps,
            max_actions_per_step=self.max_actions,
        )

        start = time.time()
        try:
            agent_result = await agent.run()

            # ── Extract JSON metadata ──────────────────────────────────
            final_msg = ""
            if agent_result.history and agent_result.history[-1].result:
                last = agent_result.history[-1].result[-1]
                final_msg = getattr(last, "extracted_content", "") or str(last)

            meta = _extract_json(final_msg)
            if meta:
                for k, v in meta.items():
                    if hasattr(result, k):
                        setattr(result, k, v)
                log.info(f"[CUA] Metadata extracted for {domain}: {meta}")
            else:
                log.warning(f"[CUA] No JSON in agent output for {domain}")

            # ── Wait for pending downloads ─────────────────────────────
            waited = 0
            while waited < self.dl_timeout:
                files = os.listdir(output_dir) if os.path.exists(output_dir) else []
                if any(f.endswith((".crdownload", ".part")) for f in files):
                    log.info(f"[CUA] Downloads in progress... ({waited:.0f}s)")
                    await asyncio.sleep(5)
                    waited += 5
                else:
                    break

            # ── Deduplicate ────────────────────────────────────────────
            unique_files = dedup.resolve()
            result.documents_downloaded = len(unique_files)
            result.downloaded_docs = "; ".join(unique_files)
            result.duplicates_removed = (
                result.documents_detected - result.documents_downloaded
                if result.documents_detected > result.documents_downloaded
                else 0
            )

            # Track duplicates from agent-reported count vs actual
            agent_downloaded = meta.get("documents_downloaded", 0) if meta else 0
            if agent_downloaded > result.documents_downloaded:
                result.duplicates_removed = agent_downloaded - result.documents_downloaded

            result.finalize()

        except Exception as e:
            log.error(f"[CUA] Agent crashed for {url}: {e}", exc_info=True)
            result.status = "error"
            result.reason = str(e)
        finally:
            result.ms = (time.time() - start) * 1000
            try:
                await browser.stop()
            except Exception:
                pass

        return result
