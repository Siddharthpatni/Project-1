"""
Vergabepilot.AI — LLM Scraper Generator (Phase 1)
==================================================
Workflow per domain:
  1. Fetch page HTML (lightweight requests + BeautifulSoup)
  2. Ask LLM to generate a complete Playwright Python scraper
  3. Execute in a sandboxed subprocess
  4. Capture error / success feedback → retry with self-healing prompt
  5. Cache successful scrapers keyed by domain

The generated scraper MUST:
  - Accept  --url  and  --output-dir  CLI arguments
  - Print JSON result to stdout on exit
  - Download all tender documents to --output-dir
"""

import asyncio
import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

log = logging.getLogger("vergabepilot.generator")

# ── Prompt templates ────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert Python/Playwright web-scraping engineer.
Your ONLY job is to write executable Python scripts that download procurement documents
from German public tender portals (Vergabeportale).

Rules:
- Use sync Playwright (playwright.sync_api)
- Accept exactly two CLI args:  --url <URL>  --output-dir <DIR>
- Download EVERY document found (PDFs, DOCXs, ZIPs, etc.)
- At the end, print ONE JSON object to stdout (nothing else):
  {"status":"success"|"partial"|"failed", "tender_name":"...", "deadline":"...",
   "organization":"...", "reference_number":"...", "documents_detected":<int>,
   "documents_downloaded":<int>, "reason":"..."}
- Handle cookie banners (click Akzeptieren / Accept / Allow)
- Handle portals that require clicking "Vergabeportal" / "Bieterzugang"
- Add waits where needed; do NOT hardcode sleeps > 3s
- Output ONLY raw Python code — no markdown fences, no explanation
"""

GENERATION_PROMPT = """
Generate a Playwright Python scraper for this tender portal.

DOMAIN: {domain}
EXAMPLE URL: {url}
PAGE STRUCTURE (trimmed HTML):
{html_snippet}

Requirements:
1. Navigate to the URL
2. Handle cookie consent dialogs
3. Extract: tender_name, deadline, organization, reference_number
4. Find ALL document download links (look for: Dokumente, Vergabeunterlagen, Downloads, Anhänge, Unterlagen tabs)
5. Download each document to --output-dir
6. Print the JSON result to stdout
7. If documents are behind a login/portal link, click through to them first

Write the complete, runnable Python script now.
"""

HEALING_PROMPT = """
The previous scraper attempt FAILED with this error:
---
{error}
---

Previous script (iteration {iteration}):
---
{prev_script}
---

Fix the script to handle this error. Common fixes:
- If timeout: add explicit waits, increase timeouts
- If selector not found: use more flexible selectors or text-based clicking
- If download not triggered: use page.expect_download() context manager
- If cookie banner blocks: add cookie dismissal before navigating
- If portal redirect needed: detect and click Vergabeportal/Bieterzugang links

Write the COMPLETE fixed script now (no markdown, no explanation).
"""

# ── HTML simplifier ──────────────────────────────────────────────────────────

def _simplify_html(html: str, max_chars: int = 8000) -> str:
    """Extract text-heavy, link-rich parts of HTML for the LLM context."""
    try:
        soup = BeautifulSoup(html, "html.parser")
        # Remove noise
        for tag in soup(["script", "style", "meta", "noscript", "svg", "img"]):
            tag.decompose()

        # Prioritise: links, buttons, form labels, headings, table cells
        priority_tags = soup.find_all(
            ["a", "button", "h1", "h2", "h3", "h4", "label", "th", "td", "span", "li"]
        )
        lines = []
        for tag in priority_tags:
            text = tag.get_text(" ", strip=True)
            href = tag.get("href", "")
            if text or href:
                lines.append(f"<{tag.name} href='{href}'>{text}</{tag.name}>")

        snippet = "\n".join(lines)
        return snippet[:max_chars]
    except Exception:
        return html[:max_chars]


# ── OpenRouter LLM call ─────────────────────────────────────────────────────

async def _llm_call(prompt: str, model: str, api_key: str) -> str:
    url = "https://api.openrouter.ai/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "model": model,
        "max_tokens": 4096,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": prompt},
        ],
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, headers=headers, json=body)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()


def _clean_code(raw: str) -> str:
    """Strip markdown fences if LLM added them despite instructions."""
    raw = re.sub(r"^```(?:python)?\n?", "", raw, flags=re.MULTILINE)
    raw = re.sub(r"\n?```$", "", raw, flags=re.MULTILINE)
    return raw.strip()


# ── Sandboxed execution ──────────────────────────────────────────────────────

def _run_script(
    script: str,
    url: str,
    output_dir: str,
    timeout: int = 120,
) -> Tuple[bool, str, str, dict]:
    """
    Run generated script in a subprocess.
    Returns (success, stdout, stderr, parsed_json_result)
    """
    with tempfile.NamedTemporaryFile(
        suffix=".py", mode="w", encoding="utf-8", delete=False
    ) as f:
        f.write(script)
        script_path = f.name

    try:
        proc = subprocess.run(
            [sys.executable, script_path, "--url", url, "--output-dir", output_dir],
            capture_output=True,
            text=True,
            timeout=timeout,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip()
        success = proc.returncode == 0

        # Try to parse JSON from stdout
        parsed = {}
        if stdout:
            try:
                # Find the last JSON object in stdout
                matches = re.findall(r"\{[^{}]*\}", stdout, re.DOTALL)
                if matches:
                    parsed = json.loads(matches[-1])
            except json.JSONDecodeError:
                pass

        return success, stdout, stderr, parsed

    except subprocess.TimeoutExpired:
        return False, "", f"Script timed out after {timeout}s", {}
    except Exception as e:
        return False, "", str(e), {}
    finally:
        os.unlink(script_path)


# ── Scraper cache ────────────────────────────────────────────────────────────

class ScraperCache:
    def __init__(self, cache_dir: str = "scraper_cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _key(self, domain: str) -> Path:
        safe = re.sub(r"[^\w.-]", "_", domain)
        return self.cache_dir / f"{safe}.py"

    def get(self, domain: str) -> Optional[str]:
        p = self._key(domain)
        if p.exists():
            log.info(f"[CACHE] Loaded scraper for {domain}")
            return p.read_text(encoding="utf-8")
        return None

    def put(self, domain: str, script: str) -> None:
        p = self._key(domain)
        p.write_text(script, encoding="utf-8")
        log.info(f"[CACHE] Saved scraper for {domain}")


# ── Main Generator class ─────────────────────────────────────────────────────

class LLMScraperGenerator:
    """
    Generates, runs, and self-heals a domain-specific Playwright scraper.
    """

    def __init__(self, api_key: str, model: str, cache_dir: str = "scraper_cache",
                 max_retries: int = 3, script_timeout: int = 120):
        self.api_key = api_key
        self.model = model
        self.cache = ScraperCache(cache_dir)
        self.max_retries = max_retries
        self.script_timeout = script_timeout

    # ------------------------------------------------------------------
    async def _fetch_html(self, url: str) -> str:
        try:
            async with httpx.AsyncClient(
                timeout=20,
                follow_redirects=True,
                headers={"User-Agent": "Mozilla/5.0 (compatible; VergabepilotBot/1.0)"},
            ) as client:
                resp = await client.get(url)
                return resp.text
        except Exception as e:
            log.warning(f"HTML fetch failed for {url}: {e}")
            return ""

    # ------------------------------------------------------------------
    async def run(self, url: str, output_dir: str) -> Tuple[bool, dict, int]:
        """
        Returns (success, result_metadata, iterations_used)
        """
        domain = urlparse(url).netloc
        os.makedirs(output_dir, exist_ok=True)

        # ── Try cached scraper first ──────────────────────────────────
        cached = self.cache.get(domain)
        if cached:
            log.info(f"[GEN] Trying cached scraper for {domain}")
            ok, stdout, stderr, parsed = _run_script(
                cached, url, output_dir, self.script_timeout
            )
            if ok and parsed.get("status") in ("success", "partial"):
                log.info(f"[GEN] Cached scraper succeeded for {domain}")
                return True, parsed, 0

        # ── Fetch HTML for context ────────────────────────────────────
        log.info(f"[GEN] Fetching HTML for {url}")
        raw_html = await self._fetch_html(url)
        html_snippet = _simplify_html(raw_html)

        # ── Generation + self-healing loop ────────────────────────────
        script = ""
        prev_error = ""
        iterations = 0

        for attempt in range(1, self.max_retries + 1):
            iterations = attempt
            log.info(f"[GEN] Generation attempt {attempt}/{self.max_retries} for {domain}")

            if attempt == 1:
                prompt = GENERATION_PROMPT.format(
                    domain=domain,
                    url=url,
                    html_snippet=html_snippet,
                )
            else:
                prompt = HEALING_PROMPT.format(
                    error=prev_error[:3000],
                    iteration=attempt - 1,
                    prev_script=script[:4000],
                )

            try:
                raw_code = await _llm_call(prompt, self.model, self.api_key)
                script = _clean_code(raw_code)
            except Exception as e:
                log.error(f"[GEN] LLM call failed: {e}")
                prev_error = str(e)
                continue

            if not script.strip().startswith(("import", "from", "#")):
                log.warning("[GEN] Generated code looks malformed, retrying")
                prev_error = "Generated code does not start with valid Python."
                continue

            # ── Run ───────────────────────────────────────────────────
            ok, stdout, stderr, parsed = _run_script(
                script, url, output_dir, self.script_timeout
            )

            log.info(f"[GEN] Script exit ok={ok} | stderr_len={len(stderr)}")
            if stderr:
                log.debug(f"[GEN] stderr:\n{stderr[:1000]}")

            if ok and parsed.get("status") in ("success", "partial"):
                log.info(f"[GEN] ✅ Scraper succeeded on attempt {attempt}")
                self.cache.put(domain, script)
                return True, parsed, iterations

            # Compose error context for next iteration
            prev_error = stderr or stdout or "Script exited non-zero with no output."
            log.warning(f"[GEN] Attempt {attempt} failed. Healing…")

        log.warning(f"[GEN] All {self.max_retries} attempts exhausted for {domain}")
        return False, {}, iterations
