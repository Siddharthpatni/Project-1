"""
Vergabepilot.AI — Main Pipeline (Phase 3 architecture)
=======================================================

Flow per URL:
  ┌─────────────────────────────────────────────┐
  │  Request (URL)                              │
  │       ↓                                     │
  │  [1] Cached / Generated LLM Scraper         │
  │       ↓ success?  ──────────────────→ Done  │
  │       ↓ fail                                │
  │  [2] CUA Agent (browser-use fallback)       │
  │       ↓ success?  ──────────────────→ Done  │
  │       ↓ fail                                │
  │  [3] Record error, continue                 │
  └─────────────────────────────────────────────┘

Deduplication runs inside BOTH paths (hash + name based).
"""

import asyncio
import hashlib
import logging
import os
import time
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

from vergabepilot.config import Config
from vergabepilot.scraper.generator import LLMScraperGenerator
from vergabepilot.agents.cua import CUAAgent
from vergabepilot.utils.dedup import Deduplicator
from vergabepilot.utils.results import ScrapeResult, SessionStats, save_results

log = logging.getLogger("vergabepilot.pipeline")


def _output_dir(base: str, url: str) -> str:
    domain   = urlparse(url).netloc
    url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
    path     = os.path.join(base, domain, url_hash)
    os.makedirs(path, exist_ok=True)
    return path


class Pipeline:
    """Orchestrates LLM scraper generation + CUA fallback for a list of URLs."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.generator = LLMScraperGenerator(
            api_key      = cfg.openrouter_api_key,
            model        = cfg.generator_model,
            cache_dir    = cfg.scraper_cache_dir,
            max_retries  = cfg.max_generator_retries,
            script_timeout = cfg.scraper_timeout_sec,
        )
        self.cua = CUAAgent(
            api_key     = cfg.openrouter_api_key,
            model       = cfg.cua_model,
            headless    = cfg.headless,
            max_steps   = cfg.cua_max_steps,
            max_actions = cfg.cua_max_actions_per_step,
            nav_timeout = cfg.nav_timeout,
            dl_timeout  = cfg.download_timeout,
        )

    # ──────────────────────────────────────────────────────────────────
    async def process_url(self, url: str) -> ScrapeResult:
        domain     = urlparse(url).netloc
        output_dir = _output_dir(self.cfg.base_download_dir, url)
        start      = time.time()

        result = ScrapeResult(url=url, domain=domain)

        # ── Phase 1: LLM-generated scraper ────────────────────────────
        log.info(f"[PIPELINE] → Phase 1 (LLM scraper) for {domain}")
        dedup = Deduplicator(output_dir, self.cfg.min_file_size_bytes)
        dedup.snapshot_before()

        try:
            ok, meta, iterations = await self.generator.run(url, output_dir)
        except Exception as e:
            log.error(f"[PIPELINE] Generator exception: {e}", exc_info=True)
            ok, meta, iterations = False, {}, 0

        if ok and meta.get("status") in ("success", "partial"):
            unique = dedup.resolve()
            result.approach_used       = "llm_scraper"
            result.scraper_iterations  = iterations
            result.documents_downloaded = len(unique)
            result.downloaded_docs     = "; ".join(unique)
            result.duplicates_removed  = max(
                0, meta.get("documents_downloaded", 0) - len(unique)
            )
            for k, v in meta.items():
                if hasattr(result, k) and k not in (
                    "documents_downloaded", "duplicates_removed"
                ):
                    setattr(result, k, v)
            result.finalize()
            result.ms = (time.time() - start) * 1000
            log.info(f"[PIPELINE] ✅ Phase 1 succeeded ({len(unique)} docs)")
            return result

        log.info(f"[PIPELINE] Phase 1 failed. → Falling back to CUA")

        # ── Phase 2: CUA fallback ──────────────────────────────────────
        log.info(f"[PIPELINE] → Phase 2 (CUA) for {domain}")
        cua_result = await self.cua.run(url, output_dir)

        # Merge: keep LLM metadata if any, override counts with CUA reality
        result.approach_used       = "llm_scraper+cua"
        result.scraper_iterations  = iterations
        result.tender_name         = cua_result.tender_name
        result.deadline            = cua_result.deadline
        result.organization        = cua_result.organization
        result.reference_number    = cua_result.reference_number
        result.documents_detected  = cua_result.documents_detected
        result.documents_downloaded = cua_result.documents_downloaded
        result.duplicates_removed  = cua_result.duplicates_removed
        result.pages_visited       = cua_result.pages_visited
        result.clicks_performed    = cua_result.clicks_performed
        result.downloaded_docs     = cua_result.downloaded_docs
        result.status              = cua_result.status
        result.reason              = cua_result.reason
        result.finalize()
        result.ms = (time.time() - start) * 1000
        return result

    # ──────────────────────────────────────────────────────────────────
    async def run_batch(self, urls: List[str]) -> List[ScrapeResult]:
        stats   = SessionStats()
        results: List[ScrapeResult] = []

        for i, url in enumerate(urls, 1):
            log.info(f"\n{'─'*60}")
            log.info(f"[PIPELINE] Processing {i}/{len(urls)}: {url}")
            log.info(f"{'─'*60}")

            r = await self.process_url(url)
            results.append(r)
            stats.update(r)

            # Live summary after each URL
            print(
                f"  [{i:>3}/{len(urls)}] {r.status.upper():<8} | "
                f"docs={r.documents_downloaded} | "
                f"dedup_removed={r.duplicates_removed} | "
                f"approach={r.approach_used} | "
                f"{r.ms/1000:.1f}s | {r.domain}"
            )

        stats.print_summary()
        save_results(results, self.cfg.result_dir)
        return results
