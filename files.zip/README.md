# Vergabepilot.AI — Phase 1: Manual Scraper

Playwright + XPath scraper for German public procurement tender portals.

## Quick Setup

```bash
pip install -r requirements.txt
playwright install chromium
```

## Hackathon Workflow

### Step 1: Inspect a sample URL from each domain

```bash
python inspect_page.py "https://www.evergabe-online.de/tenderdetails.html?id=xxx"
python inspect_page.py "https://www.dtvp.de/Satellite/notice/CXP4Y89M9..."
```

This prints all headings, key-value pairs, table structures, and suggests XPath
selectors. Use the output to tune `DOMAIN_CONFIGS` in `scraper.py`.

### Step 2: Run the scraper

```bash
python scraper.py --input urls.csv --output results.json --workers 4
```

### Step 3: Check results

- `results.json` — full structured output
- `results.csv` — quick summary for review
- `scraper.log` — debug log

## Input CSV Format

Must have a `url` column. Optional: `id`, `domain`, `trigger_id`, `procedure_id`.

```csv
id,url,domain,trigger_id,procedure_id
6a05934a-d751-4107-a1dd-dbb24ed438f7,https://www.evergabe-online.de/tenderdetails.h...,www.evergabe-online.de,b32d2a72-...,02e5e8c9-...
```

## Adding a New Domain

1. Run `inspect_page.py` on a sample URL
2. Copy the relevant XPaths from the output
3. Add a new entry to `DOMAIN_CONFIGS` in `scraper.py`
4. Test on 3-5 URLs from that domain before batch run

## Architecture

```
scraper.py          — Main scraper (CLI entry point)
inspect_page.py     — DOM inspector for discovering selectors
requirements.txt    — Dependencies
```

## Key Design Decisions

- **Per-domain configs**: Each portal has different HTML structure, so selectors
  are domain-specific. The fallback config handles unknown domains.
- **Cookie consent handling**: Auto-dismisses German cookie banners.
- **Expired tender detection**: Checks for "nicht mehr verfügbar" etc.
- **Concurrent but polite**: Semaphore-controlled concurrency, no flooding.
- **Dual output**: JSON (full data) + CSV (quick review).
- **Key-value fallback**: If named selectors miss, scrapes all dt/dd and table
  pairs as extra_fields — maximizes data capture.
